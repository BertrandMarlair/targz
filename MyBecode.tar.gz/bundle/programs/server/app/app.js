var require = meteorInstall({"imports":{"api":{"Allow.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/api/Allow.js                                                                                          //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
function adminUser(userId) {
  if (userId) {
    var adminUser = Meteor.users.findOne({
      _id: userId
    });
    return userId === adminUser._id && adminUser.profile.role === "admin";
  } else {
    return false;
  }
}

Meteor.users.allow({
  insert: function (userId, doc) {
    return adminUser(userId) || userId && doc.owner === userId;
  },
  update: function (userId, doc, fields, modifier) {
    return adminUser(userId) || doc.owner === userId;
  },
  remove: function (userId, doc) {
    return adminUser(userId) || doc.owner === userId;
  },
  fetch: ['owner']
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"CollegueTest.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/api/CollegueTest.js                                                                                   //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.export({
  Collegue: () => Collegue
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let check;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  }

}, 2);
let Project;
module.watch(require("./ProjectCollections"), {
  Project(v) {
    Project = v;
  }

}, 3);
const Collegue = Project.find({}).fetch();

if (Meteor.isServer) {
  Meteor.publish('test2', function (test) {
    return Collegue.find({});
  });
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"FeedBackCollection.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/api/FeedBackCollection.js                                                                             //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.export({
  Feedback: () => Feedback
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let check;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  }

}, 2);
const Feedback = new Mongo.Collection('feedback');

if (Meteor.isServer) {
  Meteor.publish('feedback', () => {
    return Feedback.find();
  });
  Meteor.methods({
    'feedback.insert'(name, desc) {
      check(name, String);
      check(desc, String);

      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Feedback.insert({
        name: name,
        desc: desc
      });
    },

    'feedback.remove'(id) {
      check(id, String);
      Feedback.remove(id);
    }

  });
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"FormCollection.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/api/FormCollection.js                                                                                 //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.export({
  Form: () => Form
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let check;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  }

}, 2);
const Form = new Mongo.Collection('form');

if (Meteor.isServer) {
  Meteor.publish('form', function tasksPublication() {
    return Form.find();
  });
  Meteor.methods({
    'form.insert'(title) {
      check(title, String);

      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Form.insert({
        title
      });
    },

    'form.remove'(selectId) {
      check(selectId, String);
      Form.remove(selectId);
    },

    'form.setChecked'(taskId, setChecked) {
      check(taskId, String);
      check(setChecked, Boolean);
      Form.update(taskId, {
        $set: {
          checked: setChecked
        }
      });
    }

  });
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ProjectCollections.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/api/ProjectCollections.js                                                                             //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.export({
  Project: () => Project
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let check;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  }

}, 2);
const Project = new Mongo.Collection('project');

if (Meteor.isServer) {
  Meteor.publish('project', () => {
    return Project.find();
  });
  Meteor.publish('project.one', id => {
    return Project.find({
      _id: id
    });
  });
  Meteor.publish('project.comment', id => {
    return Project.find({}, {
      "comment": 1,
      "name": 1
    });
  });
  Meteor.publish('test', test => {
    if (test) {
      return Project.find({
        collegue: {
          $in: [this.userId]
        }
      });
    }
  });
  Meteor.publish('project.userComment', () => {
    return Meteor.users.find({
      '_id': 'PsnSgvyWYzsfzgo7uid'
    });
  });
  Meteor.methods({
    'project.insert'(name, desc, owner, collegue) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      check(name, String);
      check(desc, String);
      check(owner, String);
      Project.insert({
        name,
        desc,
        owner,
        collegue,
        lanes: {}
      });
    },

    'project.remove'(selectId) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      check(selectId, String);
      Project.remove(selectId);
    },

    'project.setChecked'(taskId, setChecked) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      check(taskId, String);
      check(setChecked, Boolean);
      Project.update(taskId, {
        $set: {
          checked: setChecked
        }
      });
    },

    'project.removeCollegue'(idProject) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      check(idProject, String);
      Project.update({
        _id: idProject
      }, {
        $pull: {
          'collegue': this.userId
        }
      });
    },

    'project.updateCollegue'(idProject, collegue) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      check(idProject, String);
      check(collegue, Array);
      Project.update({
        _id: idProject
      }, {
        $set: {
          'collegue': collegue
        }
      });
    },

    'project.updateInformation'(idProject, title, description) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      check(idProject, String);
      check(title, String);
      check(description, String);
      Project.update({
        _id: idProject
      }, {
        $set: {
          'desc': description,
          'name': title
        }
      });
    },

    'project.commentInsert'(id, idProject, comment) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      check(idProject, String);
      check(comment, String);
      Project.update({
        _id: idProject
      }, {
        $push: {
          'comments': {
            '_id': id,
            'from': this.userId,
            'comment': comment
          }
        }
      });
    },

    'project.deleteComment'(idProject, id) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      check(idProject, String);
      check(id, Number);
      Project.update({
        _id: idProject
      }, {
        $pull: {
          'comments': {
            '_id': id
          }
        }
      });
    },

    'project.deleteSouscomment'(id, idProject, commentId) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Project.update({
        'comments._id': commentId
      }, {
        $pull: {
          'comments.$.sousComment': {
            'comments._id': id
          }
        }
      });
    },

    'project.addLike'(idProject, idComment) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Project.update({
        'comments._id': idComment
      }, {
        $push: {
          'comments.$.like': {
            'from': this.userId
          }
        }
      });
    },

    'project.removeLike'(idProject, idComment) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Project.update({
        'comments._id': idComment
      }, {
        $pull: {
          'comments.$.like': {
            'from': this.userId
          }
        }
      });
    },

    'project.commentByComment'(id, idProject, commentId, comment) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Project.update({
        'comments._id': commentId
      }, {
        $push: {
          'comments.$.sousComment': {
            'comments': {
              '_id': id,
              'from': this.userId,
              'comment': comment
            }
          }
        }
      });
    },

    'project.lanes'(lanes, idProject) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      check(idProject, String);
      Project.update({
        _id: idProject
      }, {
        $set: {
          'lanes': lanes
        }
      });
    },

    'project.addCate'(projectId, cateId, CurrentPage, label, style, title, cards) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Project.update({
        '_id': projectId
      }, {
        $push: {
          'lanes.lanes': {
            'id': cateId,
            'currentPage': CurrentPage,
            'label': label,
            'style': style,
            'title': title,
            'cards': cards
          }
        }
      });
    },

    'project.removeCate'(idCate, idProject) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Project.update({
        '_id': idProject
      }, {
        $pull: {
          'lanes.lanes': {
            id: idCate
          }
        }
      });
    },

    'project.imageProfile'(idProject, image) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Project.update({
        '_id': idProject
      }, {
        $set: {
          'profile': image
        }
      });
    },

    'project.imageBackground'(idProject, image) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Project.update({
        '_id': idProject
      }, {
        $set: {
          'background': image
        }
      });
    },

    'project.insertLink'(_id, idLink, link, name, ortherName) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Project.update({
        '_id': _id
      }, {
        $push: {
          'organisation.linkUrl': {
            _id: idLink,
            link: link,
            name: name,
            ortherName: ortherName
          }
        }
      });
    },

    'project.removeLink'(_id, id) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Project.update({
        '_id': _id
      }, {
        $pull: {
          'organisation.linkUrl': {
            _id: id
          }
        }
      });
    },

    'project.insertDeadLine'(_id, idDeadLine, date, title) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Project.update({
        '_id': _id
      }, {
        $push: {
          'organisation.deadline': {
            _id: idDeadLine,
            date: date,
            title: title
          }
        }
      });
    },

    'project.removeDeadLine'(_id, id) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Project.update({
        '_id': _id
      }, {
        $pull: {
          'organisation.deadline': {
            _id: id
          }
        }
      });
    },

    'project.formatorComment'(_id, formatorComment) {
      if (!Meteor.userId() && Meteor.user().profile.role === "admin") {
        throw new Meteor.Error('not-authorized');
      }

      Project.update({
        '_id': _id
      }, {
        $push: {
          'formator': formatorComment
        }
      });
    },

    'project.formatorCommenDeletet'(_id, id) {
      if (!Meteor.userId() && Meteor.user().profile.role === "admin") {
        throw new Meteor.Error('not-authorized');
      }

      Project.update({
        '_id': _id
      }, {
        $pull: {
          'formator': {
            "id": id
          }
        }
      });
    }

  });
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"PromoCollection.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/api/PromoCollection.js                                                                                //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.export({
  Promo: () => Promo
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let check;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  }

}, 2);
const Promo = new Mongo.Collection('promo');

if (Meteor.isServer) {
  Meteor.publish('promo', function tasksPublication() {
    return Promo.find();
  });
  Meteor.methods({
    'promo.insert'(ville) {
      check(ville, String);

      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Promo.insert({
        ville
      });
    },

    'promo.removeVille'(villeId) {
      check(villeId, String);
      Promo.remove({
        _id: villeId
      });
    },

    'promo.remove'(selectId) {
      check(selectId, String);
      Promo.remove(selectId);
    },

    'promo.update'(taskId) {
      check(taskId, String);
      check(setChecked, Boolean);
      Promo.update(taskId, {
        $set: promo
      });
    },

    'promo.insertPromo'(promo, villeId) {
      check(promo, String);
      check(villeId, String);
      Promo.update({
        _id: villeId
      }, {
        $push: {
          "promo": {
            $each: [promo]
          }
        }
      });
    },

    'promo.removePromo'(promo, villeId) {
      check(promo, String);
      check(villeId, String);
      Promo.update({
        _id: villeId
      }, {
        $pull: {
          'promo': promo
        }
      });
    }

  });
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"UserCollection.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/api/UserCollection.js                                                                                 //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let check;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);

if (Meteor.isServer) {
  Meteor.publish('allUsers', function (role) {
    if (role === 'admin') {
      return Meteor.users.find({}, {
        fields: {
          emails: 1,
          profile: 1,
          absences: 1,
          presences: 1,
          justify: 1,
          unjustify: 1,
          event: 1
        }
      });
    } else {
      return Meteor.users.find({
        _id: this.userId
      }, {
        fields: {
          emails: 1,
          profile: 1,
          notifications: 1,
          absences: 1,
          presences: 1,
          justify: 1,
          unjustify: 1,
          event: 1
        }
      });
    }
  });
  Meteor.publish('allUsersInfo', function (info) {
    if (info.role === 'admin') {
      return Meteor.users.find({
        _id: info.id
      }, {
        fields: {
          emails: 1,
          profile: 1,
          event: 1
        }
      });
    } else {
      return Meteor.users.find({
        _id: this.userId
      }, {
        fields: {
          emails: 1,
          profile: 1,
          event: 1
        }
      });
    }
  });
  Meteor.publish('allUsersInfoDashboard', function (role) {
    if (role === 'admin') {
      return Meteor.users.find({}, {
        fields: {
          emails: 1,
          profile: 1
        }
      });
    } else {
      return Meteor.users.find({
        _id: this.userId
      }, {
        fields: {
          emails: 1,
          profile: 1
        }
      });
    }
  });
  Meteor.publish('allUsersAbsences', function (role) {
    if (role === 'admin') {
      return Meteor.users.find({});
    } else {
      return Meteor.users.find({
        _id: this.userId
      }, {
        fields: {
          emails: 1,
          profile: 1
        }
      });
    }
  });
  Meteor.publish('userName', function (role) {
    if (role === 'admin') {
      return Meteor.users.find({});
    } else {
      return Meteor.users.find({
        _id: this.userId
      }, {
        fields: {
          profile: 1
        }
      });
    }
  });
  Meteor.publish('ownUser', function () {
    return Meteor.users.find({
      '_id': this.userId
    });
  });
  Meteor.publish('connectedUser', function () {
    return Meteor.users.find({
      _id: this.userId
    }, {
      fields: {
        emails: 1,
        profile: 1,
        event: 1,
        absences: 1
      }
    });
  });
  Meteor.publish('users', function () {
    return Meteor.users.find({}, {
      fields: {
        profile: 1,
        notifications: 1
      }
    });
  });
  Meteor.methods({
    'user.absences'(date, cause) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      check(date, String);
      check(cause, String);
      Project.update({
        _id: this.userId
      }, {
        $push: {
          'absences': date
        }
      });
    },

    'user.presences'(userId, presence) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      check(userId, String);
      const user = Meteor.users.find({
        _id: userId
      }).fetch();

      if (user.length > 0) {
        let presences = user[0].presences;
        let existDate = false;
        let existTime = false;

        for (let i in presences) {
          if (presences[i].date == presence.date) {
            existDate = true;

            if (presences[i].time.toString() !== presence.time.toString() || presences[i].comment !== presence.comment) {
              existTime = true;
            }
          }
        }

        if (existDate) {
          if (existTime) {
            Meteor.users.update({
              _id: userId
            }, {
              $pull: {
                'presences': {
                  date: presence.date
                }
              }
            });
            Meteor.users.update({
              _id: userId
            }, {
              $push: {
                'presences': presence
              }
            });
          }
        } else {
          Meteor.users.update({
            _id: userId
          }, {
            $push: {
              'presences': presence
            }
          });
        }
      }
    },

    'user.notif'(userId, notif, link) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      check(userId, String);
      check(notif, String);
      check(link, String);
      Meteor.users.update({
        _id: userId
      }, {
        $push: {
          'profile.notifications': {
            'notif': notif,
            'link': link,
            'createdAt': new Date()
          }
        }
      });
    },

    'user.notifMultiple'(userIdArray, notif, link) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      check(userIdArray, Array);
      check(notif, String);
      check(link, String);

      for (let i in userIdArray) {
        Meteor.users.update({
          _id: userIdArray[i]
        }, {
          $push: {
            'profile.notifications': {
              'notif': notif,
              'link': link,
              'createdAt': new Date()
            }
          }
        });
      }
    },

    'deleteNotification'() {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Meteor.users.update({
        _id: this.userId
      }, {
        $set: {
          'profile.notifications': []
        }
      });
    },

    'event.delete'(userId, eventId) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      check(userId, String);
      Meteor.users.update({
        _id: userId
      }, {
        $pull: {
          'event': {
            '_id': eventId
          }
        }
      });
    },

    'absence.insert'(date, cause, justificatif, type, link) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      const user = Meteor.users.find({
        _id: this.userId
      }).fetch();

      if (user.length > 0) {
        let absences = user[0].absences;
        let existDate = false;

        for (let i in absences) {
          if (absences[i].date === date) {
            existDate = true;
          }
        }

        if (!existDate) {
          Meteor.users.update({
            _id: this.userId
          }, {
            $push: {
              absences: {
                date,
                cause,
                justificatif,
                type,
                link,
                justify: ""
              }
            }
          });
        } else {
          throw new Meteor.Error('Allready added to this date :' + date);
        }
      }
    },

    'absenceMultiple.insert'(date, time, cause, justificatif, type, link) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      const user = Meteor.users.find({
        _id: this.userId
      }).fetch();

      if (user.length > 0) {
        let absences = user[0].absences;
        let existDate = false;

        for (let i in absences) {
          if (absences[i].date === date) {
            existDate = true;
          }
        }

        if (!existDate) {
          Meteor.users.update({
            _id: this.userId
          }, {
            $push: {
              absences: {
                date,
                time,
                cause,
                justificatif,
                type,
                link,
                justify: ""
              }
            }
          });
        } else {
          throw new Meteor.Error('Allready added to this date :' + date);
        }
      }
    },

    'absence.justify'(_id, justify, type) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      if (justify.absence[2] !== "") {
        Meteor.users.update({
          _id: _id,
          "absences.date": justify.absence[2].date
        }, {
          $set: {
            "absences.$.justify": true
          }
        });
      }

      if (justify.absence[1] !== "") {
        Meteor.users.update({
          _id: _id,
          "presences.date": justify.absence[1].date
        }, {
          $set: {
            "presences.$.justify": true
          }
        });
      }

      Meteor.users.update({
        _id: _id
      }, {
        $push: {
          "justify": [justify.absence[0], type]
        }
      });
    },

    'absence.newjustifylink'(link, date) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      Meteor.users.update({
        _id: this.userId,
        "absences.date": date
      }, {
        $set: {
          "absences.$.link": link
        }
      });
    },

    'absence.unJustify'(_id, justify, type) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      if (justify.absence[2] !== "") {
        Meteor.users.update({
          _id: _id,
          "absences.date": justify.absence[2].date
        }, {
          $set: {
            "absences.$.justify": false
          }
        });
      }

      if (justify.absence[1] !== "") {
        Meteor.users.update({
          _id: _id,
          "presences.date": justify.absence[1].date
        }, {
          $set: {
            "presences.$.justify": false
          }
        });
      }

      Meteor.users.update({
        _id: _id
      }, {
        $push: {
          "unjustify": [justify.absence[0], type]
        }
      });
    },

    'absence.delete'(_id, justify) {
      if (!Meteor.userId()) {
        throw new Meteor.Error('not-authorized');
      }

      if (justify.absence[2] !== "") {
        Meteor.users.update({
          _id: _id,
          "absences.date": justify.absence[2].date
        }, {
          $set: {
            "absences.$.justify": "delete"
          }
        });
      }

      if (justify.absence[1] !== "") {
        Meteor.users.update({
          _id: _id,
          "presences.date": justify.absence[1].date
        }, {
          $set: {
            "presences.$.justify": "delete"
          }
        });
      }
    }

  });
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"api.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/api/api.js                                                                                            //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.watch(require("./UserCollection.js"));
module.watch(require("./Allow.js"));
module.watch(require("./FormCollection.js"));
module.watch(require("./ProjectCollections.js"));
module.watch(require("./CollegueTest.js"));
module.watch(require("./PromoCollection"));
module.watch(require("./FeedBackCollection"));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"startup":{"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/startup/server/main.js                                                                                //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
let Inject;
module.watch(require("meteor/meteorhacks:inject-initial"), {
  Inject(v) {
    Inject = v;
  }

}, 0);
module.watch(require("../../api/api.js"));

if (Meteor.isServer) {
  Meteor.startup(() => {
    console.log("Starting server...");
    process.env.MAIL_URL = 'smtps://marlair.bertrand%40gmail.com:fArand0le@smtp.gmail.com:465';
    Accounts.emailTemplates.from = 'bertrand@becode.org';
    Accounts.emailTemplates.siteName = 'gmail.com'; // Accounts.emailTemplates.verifyEmail.subject = (user) => {
    //     return 'Confirm your adress mail';
    // }
    // Accounts.emailTemplates.verifyEmail.subject = (user, url) => {
    //     return 'Click on the following link to verify your adress Mail : ' + url;
    // }
    // Accounts.config({
    //     sendVerificationEmail:true
    // })

    Inject.rawModHtml("addLanguage", function (html) {
      return html.replace(/<html>/, '<html lang="en">');
    });
  });
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"deployAWS":{"mup.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// deployAWS/mup.js                                                                                              //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.exports = {
  servers: {
    one: {
      // TODO: set host address, username, and authentication method
      host: '54.237.213.214',
      username: 'ubuntu',
      pem: '/Users/belegan/Desktop/bertrand.pem' // password: 'fArand0le'
      // or neither for authenticate from ssh-agent

    }
  },
  app: {
    // TODO: change app name and path
    name: 'BecodeProfileManager',
    path: '../',
    servers: {
      one: {}
    },
    buildOptions: {
      serverOnly: true
    },
    env: {
      // TODO: Change to your app's url
      // If you are using ssl, it needs to start with https://
      ROOT_URL: 'https://my.becode.org',
      MONGO_URL: 'mongodb://mongodb:27017/meteorReact',
      MONGO_OPLOG_URL: 'mongodb://mongodb/local'
    },
    docker: {
      // change to 'abernix/meteord:base' if your app is using Meteor 1.4 - 1.5
      image: 'abernix/meteord:node-8.4.0-base',
      args: ['--link=mongodb:mongodb']
    },
    // Show progress bar while uploading bundle to server
    // You might need to disable it on CI servers
    enableUploadProgressBar: true
  },
  // mongo: {
  //   version: '3.4.1',
  //   servers: {
  //     one: {}
  //   }
  // },
  // (Optional)
  // Use the proxy to setup ssl or to route requests to the correct
  // app when there are several apps
  proxy: {
    domains: 'my.becode.org',
    ssl: {
      // Enable let's encrypt to create free certificates
      letsEncryptEmail: 'betrand@becode.org',
      forceSSL: true
    }
  }
};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"deployMyVPS":{"mup.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// deployMyVPS/mup.js                                                                                            //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.exports = {
  servers: {
    one: {
      // TODO: set host address, username, and authentication method
      host: '192.168.1.100',
      username: 'ubuntu',
      // pem: '/Users/admin/Desktop/bertrand.pem'
      password: 'fArand0le' // or neither for authenticate from ssh-agent

    }
  },
  app: {
    // TODO: change app name and path
    name: 'BecodeProfileManager',
    path: '../',
    servers: {
      one: {}
    },
    buildOptions: {
      serverOnly: true
    },
    env: {
      // TODO: Change to your app's url
      // If you are using ssl, it needs to start with https://
      ROOT_URL: 'http://192.168.1.100:3000',
      MONGO_URL: 'mongodb://mongodb:27017/mybecode',
      MONGO_OPLOG_URL: 'mongodb://mongodb/local'
    },
    docker: {
      // change to 'abernix/meteord:base' if your app is using Meteor 1.4 - 1.5
      image: 'abernix/meteord:node-8.4.0-base'
    },
    // Show progress bar while uploading bundle to server
    // You might need to disable it on CI servers
    enableUploadProgressBar: true
  },
  mongo: {
    version: '3.4.1',
    servers: {
      one: {}
    }
  } // (Optional)
  // Use the proxy to setup ssl or to route requests to the correct
  // app when there are several apps
  // proxy: {
  //   domains: 'marlairbertrand.tk,www.marlairbertrand.tk',
  //   ssl: {
  //     // Enable let's encrypt to create free certificates
  //     letsEncryptEmail: 'betrand@becode.org',
  //     forceSSL: true
  //   }
  // }

};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// server/main.js                                                                                                //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.watch(require("../imports/startup/server/main.js"));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx"
  ]
});
require("/deployAWS/mup.js");
require("/deployMyVPS/mup.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvQWxsb3cuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL0NvbGxlZ3VlVGVzdC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvRmVlZEJhY2tDb2xsZWN0aW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9Gb3JtQ29sbGVjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvUHJvamVjdENvbGxlY3Rpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9Qcm9tb0NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL1VzZXJDb2xsZWN0aW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9hcGkuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvbWFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvZGVwbG95QVdTL211cC5qcyIsIm1ldGVvcjovL/CfkrthcHAvZGVwbG95TXlWUFMvbXVwLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyJdLCJuYW1lcyI6WyJhZG1pblVzZXIiLCJ1c2VySWQiLCJNZXRlb3IiLCJ1c2VycyIsImZpbmRPbmUiLCJfaWQiLCJwcm9maWxlIiwicm9sZSIsImFsbG93IiwiaW5zZXJ0IiwiZG9jIiwib3duZXIiLCJ1cGRhdGUiLCJmaWVsZHMiLCJtb2RpZmllciIsInJlbW92ZSIsImZldGNoIiwibW9kdWxlIiwiZXhwb3J0IiwiQ29sbGVndWUiLCJ3YXRjaCIsInJlcXVpcmUiLCJ2IiwiTW9uZ28iLCJjaGVjayIsIlByb2plY3QiLCJmaW5kIiwiaXNTZXJ2ZXIiLCJwdWJsaXNoIiwidGVzdCIsIkZlZWRiYWNrIiwiQ29sbGVjdGlvbiIsIm1ldGhvZHMiLCJuYW1lIiwiZGVzYyIsIlN0cmluZyIsIkVycm9yIiwiaWQiLCJGb3JtIiwidGFza3NQdWJsaWNhdGlvbiIsInRpdGxlIiwic2VsZWN0SWQiLCJ0YXNrSWQiLCJzZXRDaGVja2VkIiwiQm9vbGVhbiIsIiRzZXQiLCJjaGVja2VkIiwiY29sbGVndWUiLCIkaW4iLCJsYW5lcyIsImlkUHJvamVjdCIsIiRwdWxsIiwiQXJyYXkiLCJkZXNjcmlwdGlvbiIsImNvbW1lbnQiLCIkcHVzaCIsIk51bWJlciIsImNvbW1lbnRJZCIsImlkQ29tbWVudCIsInByb2plY3RJZCIsImNhdGVJZCIsIkN1cnJlbnRQYWdlIiwibGFiZWwiLCJzdHlsZSIsImNhcmRzIiwiaWRDYXRlIiwiaW1hZ2UiLCJpZExpbmsiLCJsaW5rIiwib3J0aGVyTmFtZSIsImlkRGVhZExpbmUiLCJkYXRlIiwiZm9ybWF0b3JDb21tZW50IiwidXNlciIsIlByb21vIiwidmlsbGUiLCJ2aWxsZUlkIiwicHJvbW8iLCIkZWFjaCIsImVtYWlscyIsImFic2VuY2VzIiwicHJlc2VuY2VzIiwianVzdGlmeSIsInVuanVzdGlmeSIsImV2ZW50Iiwibm90aWZpY2F0aW9ucyIsImluZm8iLCJjYXVzZSIsInByZXNlbmNlIiwibGVuZ3RoIiwiZXhpc3REYXRlIiwiZXhpc3RUaW1lIiwiaSIsInRpbWUiLCJ0b1N0cmluZyIsIm5vdGlmIiwiRGF0ZSIsInVzZXJJZEFycmF5IiwiZXZlbnRJZCIsImp1c3RpZmljYXRpZiIsInR5cGUiLCJhYnNlbmNlIiwiSW5qZWN0Iiwic3RhcnR1cCIsImNvbnNvbGUiLCJsb2ciLCJwcm9jZXNzIiwiZW52IiwiTUFJTF9VUkwiLCJBY2NvdW50cyIsImVtYWlsVGVtcGxhdGVzIiwiZnJvbSIsInNpdGVOYW1lIiwicmF3TW9kSHRtbCIsImh0bWwiLCJyZXBsYWNlIiwiZXhwb3J0cyIsInNlcnZlcnMiLCJvbmUiLCJob3N0IiwidXNlcm5hbWUiLCJwZW0iLCJhcHAiLCJwYXRoIiwiYnVpbGRPcHRpb25zIiwic2VydmVyT25seSIsIlJPT1RfVVJMIiwiTU9OR09fVVJMIiwiTU9OR09fT1BMT0dfVVJMIiwiZG9ja2VyIiwiYXJncyIsImVuYWJsZVVwbG9hZFByb2dyZXNzQmFyIiwicHJveHkiLCJkb21haW5zIiwic3NsIiwibGV0c0VuY3J5cHRFbWFpbCIsImZvcmNlU1NMIiwicGFzc3dvcmQiLCJtb25nbyIsInZlcnNpb24iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsU0FBU0EsU0FBVCxDQUFtQkMsTUFBbkIsRUFBMkI7QUFDdkIsTUFBR0EsTUFBSCxFQUFVO0FBQ04sUUFBSUQsWUFBWUUsT0FBT0MsS0FBUCxDQUFhQyxPQUFiLENBQXFCO0FBQUNDLFdBQUtKO0FBQU4sS0FBckIsQ0FBaEI7QUFDQSxXQUFRQSxXQUFXRCxVQUFVSyxHQUFyQixJQUE0QkwsVUFBVU0sT0FBVixDQUFrQkMsSUFBbEIsS0FBMkIsT0FBL0Q7QUFDSCxHQUhELE1BR0s7QUFBQyxXQUFPLEtBQVA7QUFBYTtBQUN0Qjs7QUFDREwsT0FBT0MsS0FBUCxDQUFhSyxLQUFiLENBQW1CO0FBQ2ZDLFVBQVEsVUFBU1IsTUFBVCxFQUFpQlMsR0FBakIsRUFBcUI7QUFDekIsV0FBT1YsVUFBVUMsTUFBVixLQUFzQkEsVUFBVVMsSUFBSUMsS0FBSixLQUFjVixNQUFyRDtBQUNILEdBSGM7QUFJZlcsVUFBUSxVQUFTWCxNQUFULEVBQWlCUyxHQUFqQixFQUFzQkcsTUFBdEIsRUFBOEJDLFFBQTlCLEVBQXdDO0FBQzVDLFdBQU9kLFVBQVVDLE1BQVYsS0FBcUJTLElBQUlDLEtBQUosS0FBY1YsTUFBMUM7QUFDSCxHQU5jO0FBT2ZjLFVBQVEsVUFBVWQsTUFBVixFQUFrQlMsR0FBbEIsRUFBc0I7QUFDMUIsV0FBT1YsVUFBVUMsTUFBVixLQUFxQlMsSUFBSUMsS0FBSixLQUFjVixNQUExQztBQUNILEdBVGM7QUFVZmUsU0FBTyxDQUFDLE9BQUQ7QUFWUSxDQUFuQixFOzs7Ozs7Ozs7OztBQ05BQyxPQUFPQyxNQUFQLENBQWM7QUFBQ0MsWUFBUyxNQUFJQTtBQUFkLENBQWQ7QUFBdUMsSUFBSWpCLE1BQUo7QUFBV2UsT0FBT0csS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDbkIsU0FBT29CLENBQVAsRUFBUztBQUFDcEIsYUFBT29CLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsS0FBSjtBQUFVTixPQUFPRyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLFFBQU1ELENBQU4sRUFBUTtBQUFDQyxZQUFNRCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlFLEtBQUo7QUFBVVAsT0FBT0csS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRyxRQUFNRixDQUFOLEVBQVE7QUFBQ0UsWUFBTUYsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJRyxPQUFKO0FBQVlSLE9BQU9HLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiLEVBQTZDO0FBQUNJLFVBQVFILENBQVIsRUFBVTtBQUFDRyxjQUFRSCxDQUFSO0FBQVU7O0FBQXRCLENBQTdDLEVBQXFFLENBQXJFO0FBS2xRLE1BQU1ILFdBQVdNLFFBQVFDLElBQVIsQ0FBYSxFQUFiLEVBQWlCVixLQUFqQixFQUFqQjs7QUFFUCxJQUFJZCxPQUFPeUIsUUFBWCxFQUFvQjtBQUNoQnpCLFNBQU8wQixPQUFQLENBQWUsT0FBZixFQUF3QixVQUFTQyxJQUFULEVBQWU7QUFDbkMsV0FBT1YsU0FBU08sSUFBVCxDQUFjLEVBQWQsQ0FBUDtBQUNILEdBRkQ7QUFHSCxDOzs7Ozs7Ozs7OztBQ1hEVCxPQUFPQyxNQUFQLENBQWM7QUFBQ1ksWUFBUyxNQUFJQTtBQUFkLENBQWQ7QUFBdUMsSUFBSTVCLE1BQUo7QUFBV2UsT0FBT0csS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDbkIsU0FBT29CLENBQVAsRUFBUztBQUFDcEIsYUFBT29CLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsS0FBSjtBQUFVTixPQUFPRyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLFFBQU1ELENBQU4sRUFBUTtBQUFDQyxZQUFNRCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlFLEtBQUo7QUFBVVAsT0FBT0csS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRyxRQUFNRixDQUFOLEVBQVE7QUFBQ0UsWUFBTUYsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUkxTCxNQUFNUSxXQUFXLElBQUlQLE1BQU1RLFVBQVYsQ0FBcUIsVUFBckIsQ0FBakI7O0FBRVAsSUFBSTdCLE9BQU95QixRQUFYLEVBQXFCO0FBQ2pCekIsU0FBTzBCLE9BQVAsQ0FBZSxVQUFmLEVBQTJCLE1BQU07QUFDL0IsV0FBT0UsU0FBU0osSUFBVCxFQUFQO0FBQ0QsR0FGRDtBQUlBeEIsU0FBTzhCLE9BQVAsQ0FBZTtBQUNYLHNCQUFrQkMsSUFBbEIsRUFBd0JDLElBQXhCLEVBQThCO0FBQzFCVixZQUFNUyxJQUFOLEVBQVlFLE1BQVo7QUFDQVgsWUFBTVUsSUFBTixFQUFZQyxNQUFaOztBQUNBLFVBQUksQ0FBRWpDLE9BQU9ELE1BQVAsRUFBTixFQUF1QjtBQUNuQixjQUFNLElBQUlDLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0ROLGVBQVNyQixNQUFULENBQWdCO0FBQ1p3QixjQUFNQSxJQURNO0FBRVpDLGNBQU1BO0FBRk0sT0FBaEI7QUFJSCxLQVhVOztBQVlYLHNCQUFrQkcsRUFBbEIsRUFBc0I7QUFDbEJiLFlBQU1hLEVBQU4sRUFBVUYsTUFBVjtBQUNBTCxlQUFTZixNQUFULENBQWdCc0IsRUFBaEI7QUFDSDs7QUFmVSxHQUFmO0FBaUJILEM7Ozs7Ozs7Ozs7O0FDNUJEcEIsT0FBT0MsTUFBUCxDQUFjO0FBQUNvQixRQUFLLE1BQUlBO0FBQVYsQ0FBZDtBQUErQixJQUFJcEMsTUFBSjtBQUFXZSxPQUFPRyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNuQixTQUFPb0IsQ0FBUCxFQUFTO0FBQUNwQixhQUFPb0IsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJQyxLQUFKO0FBQVVOLE9BQU9HLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0UsUUFBTUQsQ0FBTixFQUFRO0FBQUNDLFlBQU1ELENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUUsS0FBSjtBQUFVUCxPQUFPRyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNHLFFBQU1GLENBQU4sRUFBUTtBQUFDRSxZQUFNRixDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBSWxMLE1BQU1nQixPQUFPLElBQUlmLE1BQU1RLFVBQVYsQ0FBcUIsTUFBckIsQ0FBYjs7QUFFUCxJQUFJN0IsT0FBT3lCLFFBQVgsRUFBcUI7QUFDakJ6QixTQUFPMEIsT0FBUCxDQUFlLE1BQWYsRUFBdUIsU0FBU1csZ0JBQVQsR0FBNEI7QUFDakQsV0FBT0QsS0FBS1osSUFBTCxFQUFQO0FBQ0QsR0FGRDtBQUlBeEIsU0FBTzhCLE9BQVAsQ0FBZTtBQUNYLGtCQUFjUSxLQUFkLEVBQXFCO0FBQ2pCaEIsWUFBTWdCLEtBQU4sRUFBYUwsTUFBYjs7QUFDQSxVQUFJLENBQUVqQyxPQUFPRCxNQUFQLEVBQU4sRUFBdUI7QUFDbkIsY0FBTSxJQUFJQyxPQUFPa0MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNERSxXQUFLN0IsTUFBTCxDQUFZO0FBQ1IrQjtBQURRLE9BQVo7QUFHSCxLQVRVOztBQVVYLGtCQUFjQyxRQUFkLEVBQXdCO0FBQ3BCakIsWUFBTWlCLFFBQU4sRUFBZ0JOLE1BQWhCO0FBQ0FHLFdBQUt2QixNQUFMLENBQVkwQixRQUFaO0FBQ0gsS0FiVTs7QUFjWCxzQkFBa0JDLE1BQWxCLEVBQTBCQyxVQUExQixFQUFzQztBQUNsQ25CLFlBQU1rQixNQUFOLEVBQWNQLE1BQWQ7QUFDQVgsWUFBTW1CLFVBQU4sRUFBa0JDLE9BQWxCO0FBQ0FOLFdBQUsxQixNQUFMLENBQVk4QixNQUFaLEVBQW9CO0FBQUVHLGNBQU07QUFBRUMsbUJBQVNIO0FBQVg7QUFBUixPQUFwQjtBQUNIOztBQWxCVSxHQUFmO0FBb0JILEM7Ozs7Ozs7Ozs7O0FDL0JEMUIsT0FBT0MsTUFBUCxDQUFjO0FBQUNPLFdBQVEsTUFBSUE7QUFBYixDQUFkO0FBQXFDLElBQUl2QixNQUFKO0FBQVdlLE9BQU9HLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ25CLFNBQU9vQixDQUFQLEVBQVM7QUFBQ3BCLGFBQU9vQixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlDLEtBQUo7QUFBVU4sT0FBT0csS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRSxRQUFNRCxDQUFOLEVBQVE7QUFBQ0MsWUFBTUQsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJRSxLQUFKO0FBQVVQLE9BQU9HLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0csUUFBTUYsQ0FBTixFQUFRO0FBQUNFLFlBQU1GLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFJeEwsTUFBTUcsVUFBVSxJQUFJRixNQUFNUSxVQUFWLENBQXFCLFNBQXJCLENBQWhCOztBQUVQLElBQUk3QixPQUFPeUIsUUFBWCxFQUFvQjtBQUNoQnpCLFNBQU8wQixPQUFQLENBQWUsU0FBZixFQUEwQixNQUFJO0FBQzFCLFdBQU9ILFFBQVFDLElBQVIsRUFBUDtBQUNILEdBRkQ7QUFJQXhCLFNBQU8wQixPQUFQLENBQWUsYUFBZixFQUErQlMsRUFBRCxJQUFNO0FBQ2hDLFdBQU9aLFFBQVFDLElBQVIsQ0FBYTtBQUFDckIsV0FBS2dDO0FBQU4sS0FBYixDQUFQO0FBQ0gsR0FGRDtBQUlBbkMsU0FBTzBCLE9BQVAsQ0FBZSxpQkFBZixFQUFtQ1MsRUFBRCxJQUFNO0FBQ3BDLFdBQU9aLFFBQVFDLElBQVIsQ0FBYSxFQUFiLEVBQWlCO0FBQUMsaUJBQVcsQ0FBWjtBQUFlLGNBQVE7QUFBdkIsS0FBakIsQ0FBUDtBQUNILEdBRkQ7QUFJQXhCLFNBQU8wQixPQUFQLENBQWUsTUFBZixFQUF3QkMsSUFBRCxJQUFRO0FBQzNCLFFBQUdBLElBQUgsRUFBUTtBQUNKLGFBQU9KLFFBQVFDLElBQVIsQ0FBYTtBQUFFcUIsa0JBQVU7QUFBRUMsZUFBSyxDQUFDLEtBQUsvQyxNQUFOO0FBQVA7QUFBWixPQUFiLENBQVA7QUFDSDtBQUNKLEdBSkQ7QUFNQUMsU0FBTzBCLE9BQVAsQ0FBZSxxQkFBZixFQUFzQyxNQUFJO0FBQ2xDLFdBQU8xQixPQUFPQyxLQUFQLENBQWF1QixJQUFiLENBQWtCO0FBQUMsYUFBTztBQUFSLEtBQWxCLENBQVA7QUFDUCxHQUZEO0FBSUF4QixTQUFPOEIsT0FBUCxDQUFlO0FBQ1gscUJBQWlCQyxJQUFqQixFQUF1QkMsSUFBdkIsRUFBNkJ2QixLQUE3QixFQUFvQ29DLFFBQXBDLEVBQThDO0FBQzFDLFVBQUksQ0FBQzdDLE9BQU9ELE1BQVAsRUFBTCxFQUFzQjtBQUNsQixjQUFNLElBQUlDLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0RaLFlBQU1TLElBQU4sRUFBWUUsTUFBWjtBQUNBWCxZQUFNVSxJQUFOLEVBQVlDLE1BQVo7QUFDQVgsWUFBTWIsS0FBTixFQUFhd0IsTUFBYjtBQUNBVixjQUFRaEIsTUFBUixDQUFlO0FBQ1h3QixZQURXO0FBRVhDLFlBRlc7QUFHWHZCLGFBSFc7QUFJWG9DLGdCQUpXO0FBS1hFLGVBQU87QUFMSSxPQUFmO0FBT0gsS0FmVTs7QUFnQlgscUJBQWlCUixRQUFqQixFQUEyQjtBQUN2QixVQUFJLENBQUV2QyxPQUFPRCxNQUFQLEVBQU4sRUFBdUI7QUFDbkIsY0FBTSxJQUFJQyxPQUFPa0MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNEWixZQUFNaUIsUUFBTixFQUFnQk4sTUFBaEI7QUFDQVYsY0FBUVYsTUFBUixDQUFlMEIsUUFBZjtBQUNILEtBdEJVOztBQXVCWCx5QkFBcUJDLE1BQXJCLEVBQTZCQyxVQUE3QixFQUF5QztBQUNyQyxVQUFJLENBQUV6QyxPQUFPRCxNQUFQLEVBQU4sRUFBdUI7QUFDbkIsY0FBTSxJQUFJQyxPQUFPa0MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNEWixZQUFNa0IsTUFBTixFQUFjUCxNQUFkO0FBQ0FYLFlBQU1tQixVQUFOLEVBQWtCQyxPQUFsQjtBQUNBbkIsY0FBUWIsTUFBUixDQUFlOEIsTUFBZixFQUF1QjtBQUFFRyxjQUFNO0FBQUVDLG1CQUFTSDtBQUFYO0FBQVIsT0FBdkI7QUFDSCxLQTlCVTs7QUErQlgsNkJBQXlCTyxTQUF6QixFQUFvQztBQUNoQyxVQUFJLENBQUVoRCxPQUFPRCxNQUFQLEVBQU4sRUFBdUI7QUFDbkIsY0FBTSxJQUFJQyxPQUFPa0MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNEWixZQUFNMEIsU0FBTixFQUFpQmYsTUFBakI7QUFDQVYsY0FBUWIsTUFBUixDQUNJO0FBQUVQLGFBQUs2QztBQUFQLE9BREosRUFFSTtBQUFFQyxlQUFPO0FBQUUsc0JBQVksS0FBS2xEO0FBQW5CO0FBQVQsT0FGSjtBQUlILEtBeENVOztBQXlDWCw2QkFBeUJpRCxTQUF6QixFQUFvQ0gsUUFBcEMsRUFBOEM7QUFDMUMsVUFBSSxDQUFFN0MsT0FBT0QsTUFBUCxFQUFOLEVBQXVCO0FBQ25CLGNBQU0sSUFBSUMsT0FBT2tDLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDSDs7QUFDRFosWUFBTTBCLFNBQU4sRUFBaUJmLE1BQWpCO0FBQ0FYLFlBQU11QixRQUFOLEVBQWdCSyxLQUFoQjtBQUNBM0IsY0FBUWIsTUFBUixDQUNJO0FBQUVQLGFBQUs2QztBQUFQLE9BREosRUFFSTtBQUFFTCxjQUFNO0FBQUUsc0JBQVlFO0FBQWQ7QUFBUixPQUZKO0FBSUgsS0FuRFU7O0FBb0RYLGdDQUE0QkcsU0FBNUIsRUFBdUNWLEtBQXZDLEVBQThDYSxXQUE5QyxFQUEyRDtBQUN2RCxVQUFJLENBQUVuRCxPQUFPRCxNQUFQLEVBQU4sRUFBdUI7QUFDbkIsY0FBTSxJQUFJQyxPQUFPa0MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNEWixZQUFNMEIsU0FBTixFQUFpQmYsTUFBakI7QUFDQVgsWUFBTWdCLEtBQU4sRUFBYUwsTUFBYjtBQUNBWCxZQUFNNkIsV0FBTixFQUFtQmxCLE1BQW5CO0FBQ0FWLGNBQVFiLE1BQVIsQ0FDSTtBQUFFUCxhQUFLNkM7QUFBUCxPQURKLEVBRUk7QUFBRUwsY0FBTTtBQUFFLGtCQUFRUSxXQUFWO0FBQXVCLGtCQUFRYjtBQUEvQjtBQUFSLE9BRko7QUFJSCxLQS9EVTs7QUFnRVgsNEJBQXdCSCxFQUF4QixFQUE0QmEsU0FBNUIsRUFBdUNJLE9BQXZDLEVBQWdEO0FBQzVDLFVBQUksQ0FBRXBELE9BQU9ELE1BQVAsRUFBTixFQUF1QjtBQUNuQixjQUFNLElBQUlDLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0RaLFlBQU0wQixTQUFOLEVBQWlCZixNQUFqQjtBQUNBWCxZQUFNOEIsT0FBTixFQUFlbkIsTUFBZjtBQUNBVixjQUFRYixNQUFSLENBQ0k7QUFBRVAsYUFBSzZDO0FBQVAsT0FESixFQUVJO0FBQUVLLGVBQU87QUFBRSxzQkFBYTtBQUFDLG1CQUFRbEIsRUFBVDtBQUFjLG9CQUFRLEtBQUtwQyxNQUEzQjtBQUFtQyx1QkFBV3FEO0FBQTlDO0FBQWY7QUFBVCxPQUZKO0FBSUgsS0ExRVU7O0FBMkVYLDRCQUF3QkosU0FBeEIsRUFBbUNiLEVBQW5DLEVBQXVDO0FBQ25DLFVBQUksQ0FBRW5DLE9BQU9ELE1BQVAsRUFBTixFQUF1QjtBQUNuQixjQUFNLElBQUlDLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0RaLFlBQU0wQixTQUFOLEVBQWlCZixNQUFqQjtBQUNBWCxZQUFNYSxFQUFOLEVBQVVtQixNQUFWO0FBQ0EvQixjQUFRYixNQUFSLENBQ0k7QUFBRVAsYUFBSzZDO0FBQVAsT0FESixFQUVJO0FBQUVDLGVBQU87QUFBRSxzQkFBYTtBQUFDLG1CQUFRZDtBQUFUO0FBQWY7QUFBVCxPQUZKO0FBSUgsS0FyRlU7O0FBc0ZYLGdDQUE0QkEsRUFBNUIsRUFBZ0NhLFNBQWhDLEVBQTJDTyxTQUEzQyxFQUFzRDtBQUNsRCxVQUFJLENBQUV2RCxPQUFPRCxNQUFQLEVBQU4sRUFBdUI7QUFDbkIsY0FBTSxJQUFJQyxPQUFPa0MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNEWCxjQUFRYixNQUFSLENBQ0k7QUFBQyx3QkFBZ0I2QztBQUFqQixPQURKLEVBRUk7QUFBQ04sZUFBTztBQUNKLG9DQUNJO0FBQ0ksNEJBQWdCZDtBQURwQjtBQUZBO0FBQVIsT0FGSjtBQVVILEtBcEdVOztBQXFHWCxzQkFBa0JhLFNBQWxCLEVBQTZCUSxTQUE3QixFQUF3QztBQUNwQyxVQUFJLENBQUV4RCxPQUFPRCxNQUFQLEVBQU4sRUFBdUI7QUFDbkIsY0FBTSxJQUFJQyxPQUFPa0MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNEWCxjQUFRYixNQUFSLENBQ0k7QUFBQyx3QkFBZ0I4QztBQUFqQixPQURKLEVBRUk7QUFBQ0gsZUFBTztBQUNKLDZCQUNJO0FBQ0ksb0JBQVEsS0FBS3REO0FBRGpCO0FBRkE7QUFBUixPQUZKO0FBVUgsS0FuSFU7O0FBb0hYLHlCQUFxQmlELFNBQXJCLEVBQWdDUSxTQUFoQyxFQUEyQztBQUN2QyxVQUFJLENBQUV4RCxPQUFPRCxNQUFQLEVBQU4sRUFBdUI7QUFDbkIsY0FBTSxJQUFJQyxPQUFPa0MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNEWCxjQUFRYixNQUFSLENBQ0k7QUFBQyx3QkFBZ0I4QztBQUFqQixPQURKLEVBRUk7QUFBQ1AsZUFBTztBQUNKLDZCQUNJO0FBQ0ksb0JBQVEsS0FBS2xEO0FBRGpCO0FBRkE7QUFBUixPQUZKO0FBVUgsS0FsSVU7O0FBbUlYLCtCQUEyQm9DLEVBQTNCLEVBQStCYSxTQUEvQixFQUEwQ08sU0FBMUMsRUFBcURILE9BQXJELEVBQThEO0FBQzFELFVBQUksQ0FBRXBELE9BQU9ELE1BQVAsRUFBTixFQUF1QjtBQUNuQixjQUFNLElBQUlDLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0RYLGNBQVFiLE1BQVIsQ0FDSTtBQUFDLHdCQUFnQjZDO0FBQWpCLE9BREosRUFFSTtBQUFDRixlQUFPO0FBQ0osb0NBQ0k7QUFBRSx3QkFDRTtBQUNJLHFCQUFRbEIsRUFEWjtBQUVJLHNCQUFRLEtBQUtwQyxNQUZqQjtBQUdJLHlCQUFXcUQ7QUFIZjtBQURKO0FBRkE7QUFBUixPQUZKO0FBY0gsS0FySlU7O0FBc0pYLG9CQUFnQkwsS0FBaEIsRUFBdUJDLFNBQXZCLEVBQWtDO0FBQzlCLFVBQUksQ0FBRWhELE9BQU9ELE1BQVAsRUFBTixFQUF1QjtBQUNuQixjQUFNLElBQUlDLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0RaLFlBQU0wQixTQUFOLEVBQWlCZixNQUFqQjtBQUNBVixjQUFRYixNQUFSLENBQ0k7QUFBRVAsYUFBSzZDO0FBQVAsT0FESixFQUVJO0FBQUNMLGNBQU07QUFBQyxtQkFBU0k7QUFBVjtBQUFQLE9BRko7QUFJSCxLQS9KVTs7QUFnS1gsc0JBQWtCVSxTQUFsQixFQUE0QkMsTUFBNUIsRUFBb0NDLFdBQXBDLEVBQWlEQyxLQUFqRCxFQUF3REMsS0FBeEQsRUFBK0R2QixLQUEvRCxFQUFzRXdCLEtBQXRFLEVBQTZFO0FBQ3pFLFVBQUksQ0FBRTlELE9BQU9ELE1BQVAsRUFBTixFQUF1QjtBQUNuQixjQUFNLElBQUlDLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0RYLGNBQVFiLE1BQVIsQ0FDSTtBQUFFLGVBQU8rQztBQUFULE9BREosRUFFSTtBQUFDSixlQUFPO0FBQ0oseUJBQWU7QUFDWCxrQkFBTUssTUFESztBQUVYLDJCQUFlQyxXQUZKO0FBR1gscUJBQVNDLEtBSEU7QUFJWCxxQkFBU0MsS0FKRTtBQUtYLHFCQUFTdkIsS0FMRTtBQU1YLHFCQUFTd0I7QUFORTtBQURYO0FBQVIsT0FGSjtBQWFILEtBakxVOztBQWtMWCx5QkFBcUJDLE1BQXJCLEVBQTZCZixTQUE3QixFQUF3QztBQUNwQyxVQUFJLENBQUVoRCxPQUFPRCxNQUFQLEVBQU4sRUFBdUI7QUFDbkIsY0FBTSxJQUFJQyxPQUFPa0MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNEWCxjQUFRYixNQUFSLENBQ0k7QUFBRSxlQUFPc0M7QUFBVCxPQURKLEVBRUk7QUFBRUMsZUFBTztBQUFFLHlCQUFlO0FBQUVkLGdCQUFJNEI7QUFBTjtBQUFqQjtBQUFULE9BRko7QUFJSCxLQTFMVTs7QUEyTFgsMkJBQXVCZixTQUF2QixFQUFrQ2dCLEtBQWxDLEVBQXlDO0FBQ3JDLFVBQUksQ0FBRWhFLE9BQU9ELE1BQVAsRUFBTixFQUF1QjtBQUNuQixjQUFNLElBQUlDLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0RYLGNBQVFiLE1BQVIsQ0FDSTtBQUFFLGVBQU9zQztBQUFULE9BREosRUFFSTtBQUFFTCxjQUFNO0FBQUUscUJBQVdxQjtBQUFiO0FBQVIsT0FGSjtBQUlILEtBbk1VOztBQW9NWCw4QkFBMEJoQixTQUExQixFQUFxQ2dCLEtBQXJDLEVBQTRDO0FBQ3hDLFVBQUksQ0FBRWhFLE9BQU9ELE1BQVAsRUFBTixFQUF1QjtBQUNuQixjQUFNLElBQUlDLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0RYLGNBQVFiLE1BQVIsQ0FDSTtBQUFFLGVBQU9zQztBQUFULE9BREosRUFFSTtBQUFFTCxjQUFNO0FBQUUsd0JBQWNxQjtBQUFoQjtBQUFSLE9BRko7QUFJSCxLQTVNVTs7QUE2TVgseUJBQXFCN0QsR0FBckIsRUFBMEI4RCxNQUExQixFQUFrQ0MsSUFBbEMsRUFBd0NuQyxJQUF4QyxFQUE4Q29DLFVBQTlDLEVBQTBEO0FBQ3RELFVBQUksQ0FBRW5FLE9BQU9ELE1BQVAsRUFBTixFQUF1QjtBQUNuQixjQUFNLElBQUlDLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0RYLGNBQVFiLE1BQVIsQ0FDSTtBQUFFLGVBQU9QO0FBQVQsT0FESixFQUVJO0FBQUNrRCxlQUFPO0FBQUMsa0NBQXdCO0FBQzdCbEQsaUJBQU04RCxNQUR1QjtBQUU3QkMsa0JBQU9BLElBRnNCO0FBRzdCbkMsa0JBQU9BLElBSHNCO0FBSTdCb0Msd0JBQVlBO0FBSmlCO0FBQXpCO0FBQVIsT0FGSjtBQVNILEtBMU5VOztBQTJOWCx5QkFBcUJoRSxHQUFyQixFQUEwQmdDLEVBQTFCLEVBQThCO0FBQzFCLFVBQUksQ0FBRW5DLE9BQU9ELE1BQVAsRUFBTixFQUF1QjtBQUNuQixjQUFNLElBQUlDLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0RYLGNBQVFiLE1BQVIsQ0FDSTtBQUFFLGVBQU9QO0FBQVQsT0FESixFQUVJO0FBQUM4QyxlQUFPO0FBQUMsa0NBQXdCO0FBQzdCOUMsaUJBQU1nQztBQUR1QjtBQUF6QjtBQUFSLE9BRko7QUFNSCxLQXJPVTs7QUFzT1gsNkJBQXlCaEMsR0FBekIsRUFBOEJpRSxVQUE5QixFQUEwQ0MsSUFBMUMsRUFBZ0QvQixLQUFoRCxFQUF1RDtBQUNuRCxVQUFJLENBQUV0QyxPQUFPRCxNQUFQLEVBQU4sRUFBdUI7QUFDbkIsY0FBTSxJQUFJQyxPQUFPa0MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNEWCxjQUFRYixNQUFSLENBQ0k7QUFBRSxlQUFPUDtBQUFULE9BREosRUFFSTtBQUFDa0QsZUFBTztBQUFDLG1DQUF5QjtBQUM5QmxELGlCQUFNaUUsVUFEd0I7QUFFOUJDLGtCQUFPQSxJQUZ1QjtBQUc5Qi9CLG1CQUFRQTtBQUhzQjtBQUExQjtBQUFSLE9BRko7QUFRSCxLQWxQVTs7QUFtUFgsNkJBQXlCbkMsR0FBekIsRUFBOEJnQyxFQUE5QixFQUFrQztBQUM5QixVQUFJLENBQUVuQyxPQUFPRCxNQUFQLEVBQU4sRUFBdUI7QUFDbkIsY0FBTSxJQUFJQyxPQUFPa0MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNEWCxjQUFRYixNQUFSLENBQ0k7QUFBRSxlQUFPUDtBQUFULE9BREosRUFFSTtBQUFDOEMsZUFBTztBQUFDLG1DQUF5QjtBQUM5QjlDLGlCQUFNZ0M7QUFEd0I7QUFBMUI7QUFBUixPQUZKO0FBTUgsS0E3UFU7O0FBOFBYLDhCQUEwQmhDLEdBQTFCLEVBQStCbUUsZUFBL0IsRUFBZ0Q7QUFDNUMsVUFBSSxDQUFFdEUsT0FBT0QsTUFBUCxFQUFGLElBQXFCQyxPQUFPdUUsSUFBUCxHQUFjbkUsT0FBZCxDQUFzQkMsSUFBdEIsS0FBK0IsT0FBeEQsRUFBaUU7QUFDN0QsY0FBTSxJQUFJTCxPQUFPa0MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNEWCxjQUFRYixNQUFSLENBQ0k7QUFBRSxlQUFPUDtBQUFULE9BREosRUFFSTtBQUFDa0QsZUFBTztBQUFFLHNCQUFZaUI7QUFBZDtBQUFSLE9BRko7QUFJSCxLQXRRVTs7QUF1UVgsb0NBQWdDbkUsR0FBaEMsRUFBcUNnQyxFQUFyQyxFQUF5QztBQUNyQyxVQUFJLENBQUVuQyxPQUFPRCxNQUFQLEVBQUYsSUFBcUJDLE9BQU91RSxJQUFQLEdBQWNuRSxPQUFkLENBQXNCQyxJQUF0QixLQUErQixPQUF4RCxFQUFpRTtBQUM3RCxjQUFNLElBQUlMLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0RYLGNBQVFiLE1BQVIsQ0FDSTtBQUFFLGVBQU9QO0FBQVQsT0FESixFQUVJO0FBQUM4QyxlQUFPO0FBQUUsc0JBQVk7QUFBRSxrQkFBT2Q7QUFBVDtBQUFkO0FBQVIsT0FGSjtBQUlIOztBQS9RVSxHQUFmO0FBaVJILEM7Ozs7Ozs7Ozs7O0FDOVNEcEIsT0FBT0MsTUFBUCxDQUFjO0FBQUN3RCxTQUFNLE1BQUlBO0FBQVgsQ0FBZDtBQUFpQyxJQUFJeEUsTUFBSjtBQUFXZSxPQUFPRyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNuQixTQUFPb0IsQ0FBUCxFQUFTO0FBQUNwQixhQUFPb0IsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJQyxLQUFKO0FBQVVOLE9BQU9HLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0UsUUFBTUQsQ0FBTixFQUFRO0FBQUNDLFlBQU1ELENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUUsS0FBSjtBQUFVUCxPQUFPRyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNHLFFBQU1GLENBQU4sRUFBUTtBQUFDRSxZQUFNRixDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBSXBMLE1BQU1vRCxRQUFRLElBQUluRCxNQUFNUSxVQUFWLENBQXFCLE9BQXJCLENBQWQ7O0FBRVAsSUFBSTdCLE9BQU95QixRQUFYLEVBQXFCO0FBQ2pCekIsU0FBTzBCLE9BQVAsQ0FBZSxPQUFmLEVBQXdCLFNBQVNXLGdCQUFULEdBQTRCO0FBQ2xELFdBQU9tQyxNQUFNaEQsSUFBTixFQUFQO0FBQ0QsR0FGRDtBQUlBeEIsU0FBTzhCLE9BQVAsQ0FBZTtBQUNYLG1CQUFlMkMsS0FBZixFQUFzQjtBQUNsQm5ELFlBQU1tRCxLQUFOLEVBQWF4QyxNQUFiOztBQUNBLFVBQUksQ0FBRWpDLE9BQU9ELE1BQVAsRUFBTixFQUF1QjtBQUNuQixjQUFNLElBQUlDLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0RzQyxZQUFNakUsTUFBTixDQUFhO0FBQ1RrRTtBQURTLE9BQWI7QUFHSCxLQVRVOztBQVVYLHdCQUFvQkMsT0FBcEIsRUFBNkI7QUFDekJwRCxZQUFNb0QsT0FBTixFQUFlekMsTUFBZjtBQUNBdUMsWUFBTTNELE1BQU4sQ0FBYTtBQUFFVixhQUFNdUU7QUFBUixPQUFiO0FBQ0gsS0FiVTs7QUFjWCxtQkFBZW5DLFFBQWYsRUFBeUI7QUFDckJqQixZQUFNaUIsUUFBTixFQUFnQk4sTUFBaEI7QUFDQXVDLFlBQU0zRCxNQUFOLENBQWEwQixRQUFiO0FBQ0gsS0FqQlU7O0FBa0JYLG1CQUFlQyxNQUFmLEVBQXVCO0FBQ25CbEIsWUFBTWtCLE1BQU4sRUFBY1AsTUFBZDtBQUNBWCxZQUFNbUIsVUFBTixFQUFrQkMsT0FBbEI7QUFDQThCLFlBQU05RCxNQUFOLENBQWE4QixNQUFiLEVBQXFCO0FBQUVHLGNBQU1nQztBQUFSLE9BQXJCO0FBQ0gsS0F0QlU7O0FBdUJYLHdCQUFvQkEsS0FBcEIsRUFBMkJELE9BQTNCLEVBQW9DO0FBQ2hDcEQsWUFBTXFELEtBQU4sRUFBYTFDLE1BQWI7QUFDQVgsWUFBTW9ELE9BQU4sRUFBZXpDLE1BQWY7QUFDQXVDLFlBQU05RCxNQUFOLENBQWE7QUFBRVAsYUFBTXVFO0FBQVIsT0FBYixFQUNJO0FBQUVyQixlQUNFO0FBQUUsbUJBQVU7QUFDSnVCLG1CQUFPLENBQUVELEtBQUY7QUFESDtBQUFaO0FBREosT0FESjtBQVFILEtBbENVOztBQW1DWCx3QkFBb0JBLEtBQXBCLEVBQTJCRCxPQUEzQixFQUFvQztBQUNoQ3BELFlBQU1xRCxLQUFOLEVBQWExQyxNQUFiO0FBQ0FYLFlBQU1vRCxPQUFOLEVBQWV6QyxNQUFmO0FBQ0F1QyxZQUFNOUQsTUFBTixDQUFhO0FBQUVQLGFBQU11RTtBQUFSLE9BQWIsRUFDSTtBQUFFekIsZUFDRTtBQUFFLG1CQUFTMEI7QUFBWDtBQURKLE9BREo7QUFLSDs7QUEzQ1UsR0FBZjtBQTZDSCxDOzs7Ozs7Ozs7OztBQ3hERCxJQUFJdEQsS0FBSjtBQUFVTixPQUFPRyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLFFBQU1ELENBQU4sRUFBUTtBQUFDQyxZQUFNRCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlFLEtBQUo7QUFBVVAsT0FBT0csS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRyxRQUFNRixDQUFOLEVBQVE7QUFBQ0UsWUFBTUYsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJcEIsTUFBSjtBQUFXZSxPQUFPRyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNuQixTQUFPb0IsQ0FBUCxFQUFTO0FBQUNwQixhQUFPb0IsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDs7QUFJdkosSUFBSXBCLE9BQU95QixRQUFYLEVBQXFCO0FBQ25CekIsU0FBTzBCLE9BQVAsQ0FBZSxVQUFmLEVBQTJCLFVBQVNyQixJQUFULEVBQWU7QUFDeEMsUUFBR0EsU0FBUyxPQUFaLEVBQW9CO0FBQ2xCLGFBQU9MLE9BQU9DLEtBQVAsQ0FBYXVCLElBQWIsQ0FBa0IsRUFBbEIsRUFBc0I7QUFBQ2IsZ0JBQU87QUFBQ2tFLGtCQUFPLENBQVI7QUFBV3pFLG1CQUFRLENBQW5CO0FBQXNCMEUsb0JBQVMsQ0FBL0I7QUFBa0NDLHFCQUFVLENBQTVDO0FBQStDQyxtQkFBUSxDQUF2RDtBQUEwREMscUJBQVcsQ0FBckU7QUFBd0VDLGlCQUFNO0FBQTlFO0FBQVIsT0FBdEIsQ0FBUDtBQUNELEtBRkQsTUFFSztBQUNILGFBQU9sRixPQUFPQyxLQUFQLENBQWF1QixJQUFiLENBQWtCO0FBQUNyQixhQUFNLEtBQUtKO0FBQVosT0FBbEIsRUFBdUM7QUFBQ1ksZ0JBQU87QUFBQ2tFLGtCQUFPLENBQVI7QUFBV3pFLG1CQUFRLENBQW5CO0FBQXNCK0UseUJBQWdCLENBQXRDO0FBQXlDTCxvQkFBUyxDQUFsRDtBQUFxREMscUJBQVUsQ0FBL0Q7QUFBa0VDLG1CQUFRLENBQTFFO0FBQTZFQyxxQkFBVyxDQUF4RjtBQUEyRkMsaUJBQU07QUFBakc7QUFBUixPQUF2QyxDQUFQO0FBQ0Q7QUFDRixHQU5EO0FBT0FsRixTQUFPMEIsT0FBUCxDQUFlLGNBQWYsRUFBK0IsVUFBUzBELElBQVQsRUFBZTtBQUM1QyxRQUFHQSxLQUFLL0UsSUFBTCxLQUFjLE9BQWpCLEVBQXlCO0FBQ3ZCLGFBQU9MLE9BQU9DLEtBQVAsQ0FBYXVCLElBQWIsQ0FBa0I7QUFBQ3JCLGFBQU1pRixLQUFLakQ7QUFBWixPQUFsQixFQUFtQztBQUFDeEIsZ0JBQU87QUFBQ2tFLGtCQUFPLENBQVI7QUFBV3pFLG1CQUFRLENBQW5CO0FBQXNCOEUsaUJBQU07QUFBNUI7QUFBUixPQUFuQyxDQUFQO0FBQ0QsS0FGRCxNQUVLO0FBQ0gsYUFBT2xGLE9BQU9DLEtBQVAsQ0FBYXVCLElBQWIsQ0FBa0I7QUFBQ3JCLGFBQU0sS0FBS0o7QUFBWixPQUFsQixFQUF1QztBQUFDWSxnQkFBTztBQUFDa0Usa0JBQU8sQ0FBUjtBQUFXekUsbUJBQVEsQ0FBbkI7QUFBc0I4RSxpQkFBTTtBQUE1QjtBQUFSLE9BQXZDLENBQVA7QUFDRDtBQUNGLEdBTkQ7QUFPQWxGLFNBQU8wQixPQUFQLENBQWUsdUJBQWYsRUFBd0MsVUFBU3JCLElBQVQsRUFBZTtBQUNyRCxRQUFHQSxTQUFTLE9BQVosRUFBb0I7QUFDbEIsYUFBT0wsT0FBT0MsS0FBUCxDQUFhdUIsSUFBYixDQUFrQixFQUFsQixFQUFzQjtBQUFDYixnQkFBTztBQUFDa0Usa0JBQU8sQ0FBUjtBQUFXekUsbUJBQVE7QUFBbkI7QUFBUixPQUF0QixDQUFQO0FBQ0QsS0FGRCxNQUVLO0FBQ0gsYUFBT0osT0FBT0MsS0FBUCxDQUFhdUIsSUFBYixDQUFrQjtBQUFDckIsYUFBTSxLQUFLSjtBQUFaLE9BQWxCLEVBQXVDO0FBQUNZLGdCQUFPO0FBQUNrRSxrQkFBTyxDQUFSO0FBQVd6RSxtQkFBUTtBQUFuQjtBQUFSLE9BQXZDLENBQVA7QUFDRDtBQUNGLEdBTkQ7QUFPQUosU0FBTzBCLE9BQVAsQ0FBZSxrQkFBZixFQUFtQyxVQUFTckIsSUFBVCxFQUFlO0FBQ2hELFFBQUdBLFNBQVMsT0FBWixFQUFvQjtBQUNsQixhQUFPTCxPQUFPQyxLQUFQLENBQWF1QixJQUFiLENBQWtCLEVBQWxCLENBQVA7QUFDRCxLQUZELE1BRUs7QUFDSCxhQUFPeEIsT0FBT0MsS0FBUCxDQUFhdUIsSUFBYixDQUFrQjtBQUFDckIsYUFBTSxLQUFLSjtBQUFaLE9BQWxCLEVBQXVDO0FBQUNZLGdCQUFPO0FBQUNrRSxrQkFBTyxDQUFSO0FBQVd6RSxtQkFBUTtBQUFuQjtBQUFSLE9BQXZDLENBQVA7QUFDRDtBQUNGLEdBTkQ7QUFPQUosU0FBTzBCLE9BQVAsQ0FBZSxVQUFmLEVBQTJCLFVBQVNyQixJQUFULEVBQWU7QUFDeEMsUUFBR0EsU0FBUyxPQUFaLEVBQW9CO0FBQ2xCLGFBQU9MLE9BQU9DLEtBQVAsQ0FBYXVCLElBQWIsQ0FBa0IsRUFBbEIsQ0FBUDtBQUNELEtBRkQsTUFFSztBQUNILGFBQU94QixPQUFPQyxLQUFQLENBQWF1QixJQUFiLENBQWtCO0FBQUNyQixhQUFNLEtBQUtKO0FBQVosT0FBbEIsRUFBdUM7QUFBQ1ksZ0JBQU87QUFBQ1AsbUJBQVE7QUFBVDtBQUFSLE9BQXZDLENBQVA7QUFDRDtBQUNGLEdBTkQ7QUFPQUosU0FBTzBCLE9BQVAsQ0FBZSxTQUFmLEVBQTBCLFlBQVc7QUFDakMsV0FBTzFCLE9BQU9DLEtBQVAsQ0FBYXVCLElBQWIsQ0FBa0I7QUFBQyxhQUFPLEtBQUt6QjtBQUFiLEtBQWxCLENBQVA7QUFDSCxHQUZEO0FBSUFDLFNBQU8wQixPQUFQLENBQWUsZUFBZixFQUFnQyxZQUFXO0FBQ3ZDLFdBQU8xQixPQUFPQyxLQUFQLENBQWF1QixJQUFiLENBQWtCO0FBQUNyQixXQUFNLEtBQUtKO0FBQVosS0FBbEIsRUFBdUM7QUFBQ1ksY0FBTztBQUFDa0UsZ0JBQU8sQ0FBUjtBQUFXekUsaUJBQVEsQ0FBbkI7QUFBc0I4RSxlQUFNLENBQTVCO0FBQStCSixrQkFBUztBQUF4QztBQUFSLEtBQXZDLENBQVA7QUFDSCxHQUZEO0FBSUE5RSxTQUFPMEIsT0FBUCxDQUFlLE9BQWYsRUFBd0IsWUFBVztBQUNqQyxXQUFPMUIsT0FBT0MsS0FBUCxDQUFhdUIsSUFBYixDQUFrQixFQUFsQixFQUFzQjtBQUFDYixjQUFRO0FBQUVQLGlCQUFTLENBQVg7QUFBYytFLHVCQUFlO0FBQTdCO0FBQVQsS0FBdEIsQ0FBUDtBQUNELEdBRkQ7QUFHQW5GLFNBQU84QixPQUFQLENBQWU7QUFDYixvQkFBZ0J1QyxJQUFoQixFQUFzQmdCLEtBQXRCLEVBQTZCO0FBQzNCLFVBQUksQ0FBQ3JGLE9BQU9ELE1BQVAsRUFBTCxFQUFzQjtBQUNsQixjQUFNLElBQUlDLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0RaLFlBQU0rQyxJQUFOLEVBQVlwQyxNQUFaO0FBQ0FYLFlBQU0rRCxLQUFOLEVBQWFwRCxNQUFiO0FBQ0FWLGNBQVFiLE1BQVIsQ0FDRTtBQUFFUCxhQUFLLEtBQUtKO0FBQVosT0FERixFQUVFO0FBQUVzRCxlQUFPO0FBQUUsc0JBQVlnQjtBQUFkO0FBQVQsT0FGRjtBQUlELEtBWFk7O0FBWWIscUJBQWlCdEUsTUFBakIsRUFBeUJ1RixRQUF6QixFQUFtQztBQUNqQyxVQUFJLENBQUN0RixPQUFPRCxNQUFQLEVBQUwsRUFBc0I7QUFDbEIsY0FBTSxJQUFJQyxPQUFPa0MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNEWixZQUFNdkIsTUFBTixFQUFja0MsTUFBZDtBQUNBLFlBQU1zQyxPQUFPdkUsT0FBT0MsS0FBUCxDQUFhdUIsSUFBYixDQUFrQjtBQUFDckIsYUFBS0o7QUFBTixPQUFsQixFQUFpQ2UsS0FBakMsRUFBYjs7QUFDQSxVQUFHeUQsS0FBS2dCLE1BQUwsR0FBYyxDQUFqQixFQUFtQjtBQUNqQixZQUFJUixZQUFZUixLQUFLLENBQUwsRUFBUVEsU0FBeEI7QUFDQSxZQUFJUyxZQUFZLEtBQWhCO0FBQ0EsWUFBSUMsWUFBWSxLQUFoQjs7QUFDQSxhQUFJLElBQUlDLENBQVIsSUFBYVgsU0FBYixFQUF1QjtBQUNyQixjQUFHQSxVQUFVVyxDQUFWLEVBQWFyQixJQUFiLElBQXFCaUIsU0FBU2pCLElBQWpDLEVBQXNDO0FBQ3BDbUIsd0JBQVksSUFBWjs7QUFDQSxnQkFBR1QsVUFBVVcsQ0FBVixFQUFhQyxJQUFiLENBQWtCQyxRQUFsQixPQUFpQ04sU0FBU0ssSUFBVCxDQUFjQyxRQUFkLEVBQWpDLElBQTZEYixVQUFVVyxDQUFWLEVBQWF0QyxPQUFiLEtBQXlCa0MsU0FBU2xDLE9BQWxHLEVBQTBHO0FBQ3hHcUMsMEJBQVksSUFBWjtBQUNEO0FBQ0Y7QUFDRjs7QUFDRCxZQUFHRCxTQUFILEVBQWE7QUFDWCxjQUFHQyxTQUFILEVBQWE7QUFDWHpGLG1CQUFPQyxLQUFQLENBQWFTLE1BQWIsQ0FDRTtBQUFDUCxtQkFBS0o7QUFBTixhQURGLEVBRUU7QUFBQ2tELHFCQUFNO0FBQUMsNkJBQWE7QUFBRW9CLHdCQUFNaUIsU0FBU2pCO0FBQWpCO0FBQWQ7QUFBUCxhQUZGO0FBSUFyRSxtQkFBT0MsS0FBUCxDQUFhUyxNQUFiLENBQ0U7QUFBQ1AsbUJBQUtKO0FBQU4sYUFERixFQUVFO0FBQUNzRCxxQkFBTTtBQUFDLDZCQUFhaUM7QUFBZDtBQUFQLGFBRkY7QUFJRDtBQUNGLFNBWEQsTUFXSztBQUNIdEYsaUJBQU9DLEtBQVAsQ0FBYVMsTUFBYixDQUNFO0FBQUNQLGlCQUFLSjtBQUFOLFdBREYsRUFFRTtBQUFDc0QsbUJBQU07QUFBQywyQkFBYWlDO0FBQWQ7QUFBUCxXQUZGO0FBSUQ7QUFDRjtBQUNGLEtBaERZOztBQWlEYixpQkFBYXZGLE1BQWIsRUFBcUI4RixLQUFyQixFQUE0QjNCLElBQTVCLEVBQWtDO0FBQ2hDLFVBQUksQ0FBQ2xFLE9BQU9ELE1BQVAsRUFBTCxFQUFzQjtBQUNsQixjQUFNLElBQUlDLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0RaLFlBQU12QixNQUFOLEVBQWNrQyxNQUFkO0FBQ0FYLFlBQU11RSxLQUFOLEVBQWE1RCxNQUFiO0FBQ0FYLFlBQU00QyxJQUFOLEVBQVlqQyxNQUFaO0FBQ0FqQyxhQUFPQyxLQUFQLENBQWFTLE1BQWIsQ0FDRTtBQUFFUCxhQUFLSjtBQUFQLE9BREYsRUFFRTtBQUFFc0QsZUFBTztBQUNQLG1DQUF5QjtBQUN2QixxQkFBU3dDLEtBRGM7QUFFdkIsb0JBQVEzQixJQUZlO0FBR3ZCLHlCQUFhLElBQUk0QixJQUFKO0FBSFU7QUFEbEI7QUFBVCxPQUZGO0FBVUQsS0FsRVk7O0FBbUViLHlCQUFxQkMsV0FBckIsRUFBa0NGLEtBQWxDLEVBQXlDM0IsSUFBekMsRUFBK0M7QUFDN0MsVUFBSSxDQUFDbEUsT0FBT0QsTUFBUCxFQUFMLEVBQXNCO0FBQ2xCLGNBQU0sSUFBSUMsT0FBT2tDLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDSDs7QUFDRFosWUFBTXlFLFdBQU4sRUFBbUI3QyxLQUFuQjtBQUNBNUIsWUFBTXVFLEtBQU4sRUFBYTVELE1BQWI7QUFDQVgsWUFBTTRDLElBQU4sRUFBWWpDLE1BQVo7O0FBQ0EsV0FBSSxJQUFJeUQsQ0FBUixJQUFhSyxXQUFiLEVBQXlCO0FBQ3ZCL0YsZUFBT0MsS0FBUCxDQUFhUyxNQUFiLENBQ0U7QUFBRVAsZUFBSzRGLFlBQVlMLENBQVo7QUFBUCxTQURGLEVBRUU7QUFBRXJDLGlCQUFPO0FBQ1AscUNBQXlCO0FBQ3ZCLHVCQUFTd0MsS0FEYztBQUV2QixzQkFBUTNCLElBRmU7QUFHdkIsMkJBQWEsSUFBSTRCLElBQUo7QUFIVTtBQURsQjtBQUFULFNBRkY7QUFVRDtBQUNGLEtBdEZZOztBQXVGYiwyQkFBdUI7QUFDckIsVUFBSSxDQUFDOUYsT0FBT0QsTUFBUCxFQUFMLEVBQXNCO0FBQ2xCLGNBQU0sSUFBSUMsT0FBT2tDLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDSDs7QUFDRGxDLGFBQU9DLEtBQVAsQ0FBYVMsTUFBYixDQUNFO0FBQUVQLGFBQUssS0FBS0o7QUFBWixPQURGLEVBRUU7QUFBRTRDLGNBQU07QUFBQyxtQ0FBeUI7QUFBMUI7QUFBUixPQUZGO0FBSUQsS0EvRlk7O0FBZ0diLG1CQUFlNUMsTUFBZixFQUF1QmlHLE9BQXZCLEVBQWdDO0FBQzlCLFVBQUksQ0FBQ2hHLE9BQU9ELE1BQVAsRUFBTCxFQUFzQjtBQUNsQixjQUFNLElBQUlDLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0RaLFlBQU12QixNQUFOLEVBQWNrQyxNQUFkO0FBQ0FqQyxhQUFPQyxLQUFQLENBQWFTLE1BQWIsQ0FDRTtBQUFFUCxhQUFLSjtBQUFQLE9BREYsRUFFRTtBQUFFa0QsZUFBTztBQUFDLG1CQUFTO0FBQUUsbUJBQVErQztBQUFWO0FBQVY7QUFBVCxPQUZGO0FBSUQsS0F6R1k7O0FBMEdiLHFCQUFpQjNCLElBQWpCLEVBQXVCZ0IsS0FBdkIsRUFBOEJZLFlBQTlCLEVBQTRDQyxJQUE1QyxFQUFrRGhDLElBQWxELEVBQXdEO0FBQ3RELFVBQUksQ0FBQ2xFLE9BQU9ELE1BQVAsRUFBTCxFQUFzQjtBQUNsQixjQUFNLElBQUlDLE9BQU9rQyxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBQ0QsWUFBTXFDLE9BQU92RSxPQUFPQyxLQUFQLENBQWF1QixJQUFiLENBQWtCO0FBQUNyQixhQUFLLEtBQUtKO0FBQVgsT0FBbEIsRUFBc0NlLEtBQXRDLEVBQWI7O0FBQ0EsVUFBR3lELEtBQUtnQixNQUFMLEdBQWMsQ0FBakIsRUFBbUI7QUFDakIsWUFBSVQsV0FBV1AsS0FBSyxDQUFMLEVBQVFPLFFBQXZCO0FBQ0EsWUFBSVUsWUFBWSxLQUFoQjs7QUFDQSxhQUFJLElBQUlFLENBQVIsSUFBYVosUUFBYixFQUFzQjtBQUNwQixjQUFHQSxTQUFTWSxDQUFULEVBQVlyQixJQUFaLEtBQXFCQSxJQUF4QixFQUE2QjtBQUMzQm1CLHdCQUFZLElBQVo7QUFDRDtBQUNGOztBQUNELFlBQUcsQ0FBQ0EsU0FBSixFQUFjO0FBQ1p4RixpQkFBT0MsS0FBUCxDQUFhUyxNQUFiLENBQ0U7QUFBQ1AsaUJBQU0sS0FBS0o7QUFBWixXQURGLEVBRUU7QUFBRXNELG1CQUFRO0FBQ055Qix3QkFBVztBQUNQVCxvQkFETztBQUVQZ0IscUJBRk87QUFHUFksNEJBSE87QUFJUEMsb0JBSk87QUFLUGhDLG9CQUxPO0FBTVBjLHlCQUFVO0FBTkg7QUFETDtBQUFWLFdBRkY7QUFhRCxTQWRELE1BY0s7QUFDSCxnQkFBTSxJQUFJaEYsT0FBT2tDLEtBQVgsQ0FBaUIsa0NBQWtDbUMsSUFBbkQsQ0FBTjtBQUNEO0FBQ0Y7QUFDRixLQXpJWTs7QUEwSWIsNkJBQXlCQSxJQUF6QixFQUErQnNCLElBQS9CLEVBQXFDTixLQUFyQyxFQUE0Q1ksWUFBNUMsRUFBMERDLElBQTFELEVBQWdFaEMsSUFBaEUsRUFBc0U7QUFDcEUsVUFBSSxDQUFDbEUsT0FBT0QsTUFBUCxFQUFMLEVBQXNCO0FBQ2xCLGNBQU0sSUFBSUMsT0FBT2tDLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDSDs7QUFDRCxZQUFNcUMsT0FBT3ZFLE9BQU9DLEtBQVAsQ0FBYXVCLElBQWIsQ0FBa0I7QUFBQ3JCLGFBQUssS0FBS0o7QUFBWCxPQUFsQixFQUFzQ2UsS0FBdEMsRUFBYjs7QUFDQSxVQUFHeUQsS0FBS2dCLE1BQUwsR0FBYyxDQUFqQixFQUFtQjtBQUNqQixZQUFJVCxXQUFXUCxLQUFLLENBQUwsRUFBUU8sUUFBdkI7QUFDQSxZQUFJVSxZQUFZLEtBQWhCOztBQUNBLGFBQUksSUFBSUUsQ0FBUixJQUFhWixRQUFiLEVBQXNCO0FBQ3BCLGNBQUdBLFNBQVNZLENBQVQsRUFBWXJCLElBQVosS0FBcUJBLElBQXhCLEVBQTZCO0FBQzNCbUIsd0JBQVksSUFBWjtBQUNEO0FBQ0Y7O0FBQ0QsWUFBRyxDQUFDQSxTQUFKLEVBQWM7QUFDWnhGLGlCQUFPQyxLQUFQLENBQWFTLE1BQWIsQ0FDRTtBQUFDUCxpQkFBTSxLQUFLSjtBQUFaLFdBREYsRUFFRTtBQUFFc0QsbUJBQVE7QUFDUnlCLHdCQUFXO0FBQ1BULG9CQURPO0FBRVBzQixvQkFGTztBQUdQTixxQkFITztBQUlQWSw0QkFKTztBQUtQQyxvQkFMTztBQU1QaEMsb0JBTk87QUFPUGMseUJBQVU7QUFQSDtBQURIO0FBQVYsV0FGRjtBQWVILFNBaEJDLE1BZ0JHO0FBQ0gsZ0JBQU0sSUFBSWhGLE9BQU9rQyxLQUFYLENBQWlCLGtDQUFrQ21DLElBQW5ELENBQU47QUFDRDtBQUNGO0FBQ0EsS0EzS1k7O0FBNEtiLHNCQUFrQmxFLEdBQWxCLEVBQXVCNkUsT0FBdkIsRUFBZ0NrQixJQUFoQyxFQUFzQztBQUNwQyxVQUFJLENBQUNsRyxPQUFPRCxNQUFQLEVBQUwsRUFBc0I7QUFDbEIsY0FBTSxJQUFJQyxPQUFPa0MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNELFVBQUc4QyxRQUFRbUIsT0FBUixDQUFnQixDQUFoQixNQUF1QixFQUExQixFQUE2QjtBQUMzQm5HLGVBQU9DLEtBQVAsQ0FBYVMsTUFBYixDQUNFO0FBQUNQLGVBQU1BLEdBQVA7QUFBWSwyQkFBa0I2RSxRQUFRbUIsT0FBUixDQUFnQixDQUFoQixFQUFtQjlCO0FBQWpELFNBREYsRUFFRTtBQUFDMUIsZ0JBQ0M7QUFDRSxrQ0FBdUI7QUFEekI7QUFERixTQUZGO0FBUUQ7O0FBQ0QsVUFBR3FDLFFBQVFtQixPQUFSLENBQWdCLENBQWhCLE1BQXVCLEVBQTFCLEVBQTZCO0FBQzNCbkcsZUFBT0MsS0FBUCxDQUFhUyxNQUFiLENBQ0U7QUFBQ1AsZUFBTUEsR0FBUDtBQUFZLDRCQUFtQjZFLFFBQVFtQixPQUFSLENBQWdCLENBQWhCLEVBQW1COUI7QUFBbEQsU0FERixFQUVFO0FBQUMxQixnQkFDQztBQUNFLG1DQUF3QjtBQUQxQjtBQURGLFNBRkY7QUFRRDs7QUFDRDNDLGFBQU9DLEtBQVAsQ0FBYVMsTUFBYixDQUNFO0FBQUNQLGFBQU1BO0FBQVAsT0FERixFQUVFO0FBQUNrRCxlQUNDO0FBQ0UscUJBQVksQ0FBQzJCLFFBQVFtQixPQUFSLENBQWdCLENBQWhCLENBQUQsRUFBcUJELElBQXJCO0FBRGQ7QUFERixPQUZGO0FBUUQsS0E1TVk7O0FBNk1iLDZCQUF5QmhDLElBQXpCLEVBQStCRyxJQUEvQixFQUFxQztBQUNuQyxVQUFJLENBQUNyRSxPQUFPRCxNQUFQLEVBQUwsRUFBc0I7QUFDbEIsY0FBTSxJQUFJQyxPQUFPa0MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNEbEMsYUFBT0MsS0FBUCxDQUFhUyxNQUFiLENBQ0U7QUFBQ1AsYUFBTSxLQUFLSixNQUFaO0FBQW9CLHlCQUFrQnNFO0FBQXRDLE9BREYsRUFFRTtBQUFDMUIsY0FDQztBQUNFLDZCQUFvQnVCO0FBRHRCO0FBREYsT0FGRjtBQVFELEtBek5ZOztBQTBOYix3QkFBb0IvRCxHQUFwQixFQUF5QjZFLE9BQXpCLEVBQWtDa0IsSUFBbEMsRUFBd0M7QUFDdEMsVUFBSSxDQUFDbEcsT0FBT0QsTUFBUCxFQUFMLEVBQXNCO0FBQ2xCLGNBQU0sSUFBSUMsT0FBT2tDLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDSDs7QUFDRCxVQUFHOEMsUUFBUW1CLE9BQVIsQ0FBZ0IsQ0FBaEIsTUFBdUIsRUFBMUIsRUFBNkI7QUFDM0JuRyxlQUFPQyxLQUFQLENBQWFTLE1BQWIsQ0FDRTtBQUFDUCxlQUFNQSxHQUFQO0FBQVksMkJBQWtCNkUsUUFBUW1CLE9BQVIsQ0FBZ0IsQ0FBaEIsRUFBbUI5QjtBQUFqRCxTQURGLEVBRUU7QUFBQzFCLGdCQUNDO0FBQ0Usa0NBQXVCO0FBRHpCO0FBREYsU0FGRjtBQVFEOztBQUNELFVBQUdxQyxRQUFRbUIsT0FBUixDQUFnQixDQUFoQixNQUF1QixFQUExQixFQUE2QjtBQUMzQm5HLGVBQU9DLEtBQVAsQ0FBYVMsTUFBYixDQUNFO0FBQUNQLGVBQU1BLEdBQVA7QUFBWSw0QkFBbUI2RSxRQUFRbUIsT0FBUixDQUFnQixDQUFoQixFQUFtQjlCO0FBQWxELFNBREYsRUFFRTtBQUFDMUIsZ0JBQ0M7QUFDRSxtQ0FBd0I7QUFEMUI7QUFERixTQUZGO0FBUUQ7O0FBQ0QzQyxhQUFPQyxLQUFQLENBQWFTLE1BQWIsQ0FDRTtBQUFDUCxhQUFNQTtBQUFQLE9BREYsRUFFRTtBQUFDa0QsZUFDQztBQUNFLHVCQUFjLENBQUMyQixRQUFRbUIsT0FBUixDQUFnQixDQUFoQixDQUFELEVBQXFCRCxJQUFyQjtBQURoQjtBQURGLE9BRkY7QUFRRCxLQTFQWTs7QUEyUGIscUJBQWlCL0YsR0FBakIsRUFBc0I2RSxPQUF0QixFQUErQjtBQUM3QixVQUFJLENBQUNoRixPQUFPRCxNQUFQLEVBQUwsRUFBc0I7QUFDbEIsY0FBTSxJQUFJQyxPQUFPa0MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNELFVBQUc4QyxRQUFRbUIsT0FBUixDQUFnQixDQUFoQixNQUF1QixFQUExQixFQUE2QjtBQUMzQm5HLGVBQU9DLEtBQVAsQ0FBYVMsTUFBYixDQUNFO0FBQUNQLGVBQU1BLEdBQVA7QUFBWSwyQkFBa0I2RSxRQUFRbUIsT0FBUixDQUFnQixDQUFoQixFQUFtQjlCO0FBQWpELFNBREYsRUFFRTtBQUFDMUIsZ0JBQ0M7QUFDRSxrQ0FBdUI7QUFEekI7QUFERixTQUZGO0FBUUQ7O0FBQ0QsVUFBR3FDLFFBQVFtQixPQUFSLENBQWdCLENBQWhCLE1BQXVCLEVBQTFCLEVBQTZCO0FBQzNCbkcsZUFBT0MsS0FBUCxDQUFhUyxNQUFiLENBQ0U7QUFBQ1AsZUFBTUEsR0FBUDtBQUFZLDRCQUFtQjZFLFFBQVFtQixPQUFSLENBQWdCLENBQWhCLEVBQW1COUI7QUFBbEQsU0FERixFQUVFO0FBQUMxQixnQkFDQztBQUNFLG1DQUF3QjtBQUQxQjtBQURGLFNBRkY7QUFRRDtBQUNGOztBQW5SWSxHQUFmO0FBcVJELEM7Ozs7Ozs7Ozs7O0FDeFVENUIsT0FBT0csS0FBUCxDQUFhQyxRQUFRLHFCQUFSLENBQWI7QUFBNkNKLE9BQU9HLEtBQVAsQ0FBYUMsUUFBUSxZQUFSLENBQWI7QUFBb0NKLE9BQU9HLEtBQVAsQ0FBYUMsUUFBUSxxQkFBUixDQUFiO0FBQTZDSixPQUFPRyxLQUFQLENBQWFDLFFBQVEseUJBQVIsQ0FBYjtBQUFpREosT0FBT0csS0FBUCxDQUFhQyxRQUFRLG1CQUFSLENBQWI7QUFBMkNKLE9BQU9HLEtBQVAsQ0FBYUMsUUFBUSxtQkFBUixDQUFiO0FBQTJDSixPQUFPRyxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYixFOzs7Ozs7Ozs7OztBQ0FyUSxJQUFJaUYsTUFBSjtBQUFXckYsT0FBT0csS0FBUCxDQUFhQyxRQUFRLG1DQUFSLENBQWIsRUFBMEQ7QUFBQ2lGLFNBQU9oRixDQUFQLEVBQVM7QUFBQ2dGLGFBQU9oRixDQUFQO0FBQVM7O0FBQXBCLENBQTFELEVBQWdGLENBQWhGO0FBQW1GTCxPQUFPRyxLQUFQLENBQWFDLFFBQVEsa0JBQVIsQ0FBYjs7QUFJOUYsSUFBR25CLE9BQU95QixRQUFWLEVBQW1CO0FBQ2Z6QixTQUFPcUcsT0FBUCxDQUFlLE1BQU07QUFDakJDLFlBQVFDLEdBQVIsQ0FBWSxvQkFBWjtBQUNBQyxZQUFRQyxHQUFSLENBQVlDLFFBQVosR0FBcUIsbUVBQXJCO0FBRUFDLGFBQVNDLGNBQVQsQ0FBd0JDLElBQXhCLEdBQTZCLHFCQUE3QjtBQUNBRixhQUFTQyxjQUFULENBQXdCRSxRQUF4QixHQUFpQyxXQUFqQyxDQUxpQixDQU9qQjtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBRUFWLFdBQU9XLFVBQVAsQ0FBa0IsYUFBbEIsRUFBaUMsVUFBU0MsSUFBVCxFQUFlO0FBQzVDLGFBQU9BLEtBQUtDLE9BQUwsQ0FBYSxRQUFiLEVBQXVCLGtCQUF2QixDQUFQO0FBQ0gsS0FGRDtBQUdILEdBdEJEO0FBdUJILEM7Ozs7Ozs7Ozs7O0FDNUJEbEcsT0FBT21HLE9BQVAsR0FBaUI7QUFDZkMsV0FBUztBQUNQQyxTQUFLO0FBQ0g7QUFDQUMsWUFBTSxnQkFGSDtBQUdIQyxnQkFBVSxRQUhQO0FBSUhDLFdBQUsscUNBSkYsQ0FLSDtBQUNBOztBQU5HO0FBREUsR0FETTtBQVlmQyxPQUFLO0FBQ0g7QUFDQXpGLFVBQU0sc0JBRkg7QUFHSDBGLFVBQU0sS0FISDtBQUtITixhQUFTO0FBQ1BDLFdBQUs7QUFERSxLQUxOO0FBU0hNLGtCQUFjO0FBQ1pDLGtCQUFZO0FBREEsS0FUWDtBQWFIbEIsU0FBSztBQUNIO0FBQ0E7QUFDQW1CLGdCQUFVLHVCQUhQO0FBSUhDLGlCQUFXLHFDQUpSO0FBS0hDLHVCQUFpQjtBQUxkLEtBYkY7QUFxQkhDLFlBQVE7QUFDTjtBQUNBL0QsYUFBTyxpQ0FGRDtBQUdOZ0UsWUFBTSxDQUNKLHdCQURJO0FBSEEsS0FyQkw7QUE2Qkg7QUFDQTtBQUNBQyw2QkFBeUI7QUEvQnRCLEdBWlU7QUE4Q2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBRUFDLFNBQU87QUFDTEMsYUFBUyxlQURKO0FBRUxDLFNBQUs7QUFDSDtBQUNBQyx3QkFBa0Isb0JBRmY7QUFHSEMsZ0JBQVU7QUFIUDtBQUZBO0FBMURRLENBQWpCLEM7Ozs7Ozs7Ozs7O0FDQUF2SCxPQUFPbUcsT0FBUCxHQUFpQjtBQUNmQyxXQUFTO0FBQ1BDLFNBQUs7QUFDSDtBQUNBQyxZQUFNLGVBRkg7QUFHSEMsZ0JBQVUsUUFIUDtBQUlIO0FBQ0FpQixnQkFBVSxXQUxQLENBTUg7O0FBTkc7QUFERSxHQURNO0FBWWZmLE9BQUs7QUFDSDtBQUNBekYsVUFBTSxzQkFGSDtBQUdIMEYsVUFBTSxLQUhIO0FBS0hOLGFBQVM7QUFDUEMsV0FBSztBQURFLEtBTE47QUFTSE0sa0JBQWM7QUFDWkMsa0JBQVk7QUFEQSxLQVRYO0FBYUhsQixTQUFLO0FBQ0g7QUFDQTtBQUNBbUIsZ0JBQVUsMkJBSFA7QUFJSEMsaUJBQVcsa0NBSlI7QUFLSEMsdUJBQWlCO0FBTGQsS0FiRjtBQXFCSEMsWUFBUTtBQUNOO0FBQ0EvRCxhQUFPO0FBRkQsS0FyQkw7QUEwQkg7QUFDQTtBQUNBaUUsNkJBQXlCO0FBNUJ0QixHQVpVO0FBMkNmTyxTQUFPO0FBQ0xDLGFBQVMsT0FESjtBQUVMdEIsYUFBUztBQUNQQyxXQUFLO0FBREU7QUFGSixHQTNDUSxDQW1EZjtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQTlEZSxDQUFqQixDOzs7Ozs7Ozs7OztBQ0FBckcsT0FBT0csS0FBUCxDQUFhQyxRQUFRLG1DQUFSLENBQWIsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiZnVuY3Rpb24gYWRtaW5Vc2VyKHVzZXJJZCkge1xuICAgIGlmKHVzZXJJZCl7XG4gICAgICAgIHZhciBhZG1pblVzZXIgPSBNZXRlb3IudXNlcnMuZmluZE9uZSh7X2lkOiB1c2VySWR9KTtcbiAgICAgICAgcmV0dXJuICh1c2VySWQgPT09IGFkbWluVXNlci5faWQgJiYgYWRtaW5Vc2VyLnByb2ZpbGUucm9sZSA9PT0gXCJhZG1pblwiKTtcbiAgICB9ZWxzZXtyZXR1cm4gZmFsc2V9XG59XG5NZXRlb3IudXNlcnMuYWxsb3coe1xuICAgIGluc2VydDogZnVuY3Rpb24odXNlcklkLCBkb2Mpe1xuICAgICAgICByZXR1cm4gYWRtaW5Vc2VyKHVzZXJJZCkgfHwgKHVzZXJJZCAmJiBkb2Mub3duZXIgPT09IHVzZXJJZCk7XG4gICAgfSxcbiAgICB1cGRhdGU6IGZ1bmN0aW9uKHVzZXJJZCwgZG9jLCBmaWVsZHMsIG1vZGlmaWVyKSB7XG4gICAgICAgIHJldHVybiBhZG1pblVzZXIodXNlcklkKSB8fCBkb2Mub3duZXIgPT09IHVzZXJJZDtcbiAgICB9LFxuICAgIHJlbW92ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKXtcbiAgICAgICAgcmV0dXJuIGFkbWluVXNlcih1c2VySWQpIHx8IGRvYy5vd25lciA9PT0gdXNlcklkO1xuICAgIH0sXG4gICAgZmV0Y2g6IFsnb3duZXInXVxufSk7IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBQcm9qZWN0IH0gZnJvbSAnLi9Qcm9qZWN0Q29sbGVjdGlvbnMnO1xuIFxuZXhwb3J0IGNvbnN0IENvbGxlZ3VlID0gUHJvamVjdC5maW5kKHt9KS5mZXRjaCgpO1xuIFxuaWYgKE1ldGVvci5pc1NlcnZlcil7XG4gICAgTWV0ZW9yLnB1Ymxpc2goJ3Rlc3QyJywgZnVuY3Rpb24odGVzdCkge1xuICAgICAgICByZXR1cm4gQ29sbGVndWUuZmluZCh7fSk7XG4gICAgfSk7XG59XG5cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuIFxuZXhwb3J0IGNvbnN0IEZlZWRiYWNrID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2ZlZWRiYWNrJyk7XG4gXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgTWV0ZW9yLnB1Ymxpc2goJ2ZlZWRiYWNrJywgKCkgPT4ge1xuICAgICAgcmV0dXJuIEZlZWRiYWNrLmZpbmQoKTtcbiAgICB9KTtcblxuICAgIE1ldGVvci5tZXRob2RzKHtcbiAgICAgICAgJ2ZlZWRiYWNrLmluc2VydCcobmFtZSwgZGVzYykge1xuICAgICAgICAgICAgY2hlY2sobmFtZSwgU3RyaW5nKTtcbiAgICAgICAgICAgIGNoZWNrKGRlc2MsIFN0cmluZyk7XG4gICAgICAgICAgICBpZiAoISBNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgRmVlZGJhY2suaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICBuYW1lOiBuYW1lLFxuICAgICAgICAgICAgICAgIGRlc2M6IGRlc2MsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSxcbiAgICAgICAgJ2ZlZWRiYWNrLnJlbW92ZScoaWQpIHtcbiAgICAgICAgICAgIGNoZWNrKGlkLCBTdHJpbmcpO1xuICAgICAgICAgICAgRmVlZGJhY2sucmVtb3ZlKGlkKTtcbiAgICAgICAgfSxcbiAgICB9KTtcbn0iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbiBcbmV4cG9ydCBjb25zdCBGb3JtID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2Zvcm0nKTtcbiBcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgICBNZXRlb3IucHVibGlzaCgnZm9ybScsIGZ1bmN0aW9uIHRhc2tzUHVibGljYXRpb24oKSB7XG4gICAgICByZXR1cm4gRm9ybS5maW5kKCk7XG4gICAgfSk7XG5cbiAgICBNZXRlb3IubWV0aG9kcyh7XG4gICAgICAgICdmb3JtLmluc2VydCcodGl0bGUpIHtcbiAgICAgICAgICAgIGNoZWNrKHRpdGxlLCBTdHJpbmcpO1xuICAgICAgICAgICAgaWYgKCEgTWV0ZW9yLnVzZXJJZCgpKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEZvcm0uaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICB0aXRsZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICAgICdmb3JtLnJlbW92ZScoc2VsZWN0SWQpIHtcbiAgICAgICAgICAgIGNoZWNrKHNlbGVjdElkLCBTdHJpbmcpO1xuICAgICAgICAgICAgRm9ybS5yZW1vdmUoc2VsZWN0SWQpO1xuICAgICAgICB9LFxuICAgICAgICAnZm9ybS5zZXRDaGVja2VkJyh0YXNrSWQsIHNldENoZWNrZWQpIHtcbiAgICAgICAgICAgIGNoZWNrKHRhc2tJZCwgU3RyaW5nKTtcbiAgICAgICAgICAgIGNoZWNrKHNldENoZWNrZWQsIEJvb2xlYW4pO1xuICAgICAgICAgICAgRm9ybS51cGRhdGUodGFza0lkLCB7ICRzZXQ6IHsgY2hlY2tlZDogc2V0Q2hlY2tlZCB9IH0pO1xuICAgICAgICB9LFxuICAgIH0pO1xufSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuIFxuZXhwb3J0IGNvbnN0IFByb2plY3QgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncHJvamVjdCcpO1xuIFxuaWYgKE1ldGVvci5pc1NlcnZlcil7XG4gICAgTWV0ZW9yLnB1Ymxpc2goJ3Byb2plY3QnLCAoKT0+e1xuICAgICAgICByZXR1cm4gUHJvamVjdC5maW5kKCk7XG4gICAgfSk7XG5cbiAgICBNZXRlb3IucHVibGlzaCgncHJvamVjdC5vbmUnLCAoaWQpPT57XG4gICAgICAgIHJldHVybiBQcm9qZWN0LmZpbmQoe19pZDogaWR9KVxuICAgIH0pXG5cbiAgICBNZXRlb3IucHVibGlzaCgncHJvamVjdC5jb21tZW50JywgKGlkKT0+e1xuICAgICAgICByZXR1cm4gUHJvamVjdC5maW5kKHt9LCB7XCJjb21tZW50XCI6IDEsIFwibmFtZVwiOiAxfSlcbiAgICB9KVxuXG4gICAgTWV0ZW9yLnB1Ymxpc2goJ3Rlc3QnLCAodGVzdCk9PntcbiAgICAgICAgaWYodGVzdCl7XG4gICAgICAgICAgICByZXR1cm4gUHJvamVjdC5maW5kKHsgY29sbGVndWU6IHsgJGluOiBbdGhpcy51c2VySWRdIH0gfSlcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgTWV0ZW9yLnB1Ymxpc2goJ3Byb2plY3QudXNlckNvbW1lbnQnLCAoKT0+e1xuICAgICAgICAgICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kKHsnX2lkJzogJ1BzblNndnlXWXpzZnpnbzd1aWQnfSlcbiAgICB9KTtcblxuICAgIE1ldGVvci5tZXRob2RzKHtcbiAgICAgICAgJ3Byb2plY3QuaW5zZXJ0JyhuYW1lLCBkZXNjLCBvd25lciwgY29sbGVndWUpIHtcbiAgICAgICAgICAgIGlmICghTWV0ZW9yLnVzZXJJZCgpKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNoZWNrKG5hbWUsIFN0cmluZyk7XG4gICAgICAgICAgICBjaGVjayhkZXNjLCBTdHJpbmcpO1xuICAgICAgICAgICAgY2hlY2sob3duZXIsIFN0cmluZyk7XG4gICAgICAgICAgICBQcm9qZWN0Lmluc2VydCh7XG4gICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICBkZXNjLFxuICAgICAgICAgICAgICAgIG93bmVyLFxuICAgICAgICAgICAgICAgIGNvbGxlZ3VlLFxuICAgICAgICAgICAgICAgIGxhbmVzOiB7fVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICAgICdwcm9qZWN0LnJlbW92ZScoc2VsZWN0SWQpIHtcbiAgICAgICAgICAgIGlmICghIE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjaGVjayhzZWxlY3RJZCwgU3RyaW5nKTtcbiAgICAgICAgICAgIFByb2plY3QucmVtb3ZlKHNlbGVjdElkKTtcbiAgICAgICAgfSxcbiAgICAgICAgJ3Byb2plY3Quc2V0Q2hlY2tlZCcodGFza0lkLCBzZXRDaGVja2VkKSB7XG4gICAgICAgICAgICBpZiAoISBNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2hlY2sodGFza0lkLCBTdHJpbmcpO1xuICAgICAgICAgICAgY2hlY2soc2V0Q2hlY2tlZCwgQm9vbGVhbik7XG4gICAgICAgICAgICBQcm9qZWN0LnVwZGF0ZSh0YXNrSWQsIHsgJHNldDogeyBjaGVja2VkOiBzZXRDaGVja2VkIH0gfSk7XG4gICAgICAgIH0sXG4gICAgICAgICdwcm9qZWN0LnJlbW92ZUNvbGxlZ3VlJyhpZFByb2plY3QpIHtcbiAgICAgICAgICAgIGlmICghIE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjaGVjayhpZFByb2plY3QsIFN0cmluZyk7XG4gICAgICAgICAgICBQcm9qZWN0LnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7IF9pZDogaWRQcm9qZWN0IH0sXG4gICAgICAgICAgICAgICAgeyAkcHVsbDogeyAnY29sbGVndWUnOiB0aGlzLnVzZXJJZCB9IH1cbiAgICAgICAgICAgICk7XG4gICAgICAgIH0sXG4gICAgICAgICdwcm9qZWN0LnVwZGF0ZUNvbGxlZ3VlJyhpZFByb2plY3QsIGNvbGxlZ3VlKSB7XG4gICAgICAgICAgICBpZiAoISBNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2hlY2soaWRQcm9qZWN0LCBTdHJpbmcpO1xuICAgICAgICAgICAgY2hlY2soY29sbGVndWUsIEFycmF5KTtcbiAgICAgICAgICAgIFByb2plY3QudXBkYXRlKFxuICAgICAgICAgICAgICAgIHsgX2lkOiBpZFByb2plY3QgfSxcbiAgICAgICAgICAgICAgICB7ICRzZXQ6IHsgJ2NvbGxlZ3VlJzogY29sbGVndWUgfX1cbiAgICAgICAgICAgICk7XG4gICAgICAgIH0sXG4gICAgICAgICdwcm9qZWN0LnVwZGF0ZUluZm9ybWF0aW9uJyhpZFByb2plY3QsIHRpdGxlLCBkZXNjcmlwdGlvbikge1xuICAgICAgICAgICAgaWYgKCEgTWV0ZW9yLnVzZXJJZCgpKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNoZWNrKGlkUHJvamVjdCwgU3RyaW5nKTtcbiAgICAgICAgICAgIGNoZWNrKHRpdGxlLCBTdHJpbmcpO1xuICAgICAgICAgICAgY2hlY2soZGVzY3JpcHRpb24sIFN0cmluZyk7XG4gICAgICAgICAgICBQcm9qZWN0LnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7IF9pZDogaWRQcm9qZWN0IH0sXG4gICAgICAgICAgICAgICAgeyAkc2V0OiB7ICdkZXNjJzogZGVzY3JpcHRpb24sICduYW1lJzogdGl0bGUgfX1cbiAgICAgICAgICAgICk7XG4gICAgICAgIH0sXG4gICAgICAgICdwcm9qZWN0LmNvbW1lbnRJbnNlcnQnKGlkLCBpZFByb2plY3QsIGNvbW1lbnQpIHtcbiAgICAgICAgICAgIGlmICghIE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjaGVjayhpZFByb2plY3QsIFN0cmluZyk7XG4gICAgICAgICAgICBjaGVjayhjb21tZW50LCBTdHJpbmcpO1xuICAgICAgICAgICAgUHJvamVjdC51cGRhdGUoXG4gICAgICAgICAgICAgICAgeyBfaWQ6IGlkUHJvamVjdCB9LFxuICAgICAgICAgICAgICAgIHsgJHB1c2g6IHsgJ2NvbW1lbnRzJyA6IHsnX2lkJyA6IGlkICwgJ2Zyb20nOiB0aGlzLnVzZXJJZCwgJ2NvbW1lbnQnOiBjb21tZW50IH0gfSB9XG4gICAgICAgICAgICApO1xuICAgICAgICB9LFxuICAgICAgICAncHJvamVjdC5kZWxldGVDb21tZW50JyhpZFByb2plY3QsIGlkKSB7XG4gICAgICAgICAgICBpZiAoISBNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2hlY2soaWRQcm9qZWN0LCBTdHJpbmcpO1xuICAgICAgICAgICAgY2hlY2soaWQsIE51bWJlcik7XG4gICAgICAgICAgICBQcm9qZWN0LnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7IF9pZDogaWRQcm9qZWN0IH0sXG4gICAgICAgICAgICAgICAgeyAkcHVsbDogeyAnY29tbWVudHMnIDogeydfaWQnIDogaWQgfSB9IH1cbiAgICAgICAgICAgICk7XG4gICAgICAgIH0sXG4gICAgICAgICdwcm9qZWN0LmRlbGV0ZVNvdXNjb21tZW50JyhpZCwgaWRQcm9qZWN0LCBjb21tZW50SWQpIHtcbiAgICAgICAgICAgIGlmICghIE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBQcm9qZWN0LnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7J2NvbW1lbnRzLl9pZCc6IGNvbW1lbnRJZH0sIFxuICAgICAgICAgICAgICAgIHskcHVsbDoge1xuICAgICAgICAgICAgICAgICAgICAnY29tbWVudHMuJC5zb3VzQ29tbWVudCc6IFxuICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICdjb21tZW50cy5faWQnOiBpZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9ICAgIFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSxcbiAgICAgICAgJ3Byb2plY3QuYWRkTGlrZScoaWRQcm9qZWN0LCBpZENvbW1lbnQpIHtcbiAgICAgICAgICAgIGlmICghIE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBQcm9qZWN0LnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7J2NvbW1lbnRzLl9pZCc6IGlkQ29tbWVudH0sIFxuICAgICAgICAgICAgICAgIHskcHVzaDoge1xuICAgICAgICAgICAgICAgICAgICAnY29tbWVudHMuJC5saWtlJzogXG4gICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2Zyb20nOiB0aGlzLnVzZXJJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9ICAgIFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSxcbiAgICAgICAgJ3Byb2plY3QucmVtb3ZlTGlrZScoaWRQcm9qZWN0LCBpZENvbW1lbnQpIHtcbiAgICAgICAgICAgIGlmICghIE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBQcm9qZWN0LnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7J2NvbW1lbnRzLl9pZCc6IGlkQ29tbWVudH0sIFxuICAgICAgICAgICAgICAgIHskcHVsbDoge1xuICAgICAgICAgICAgICAgICAgICAnY29tbWVudHMuJC5saWtlJzogXG4gICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2Zyb20nOiB0aGlzLnVzZXJJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9ICAgIFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSxcbiAgICAgICAgJ3Byb2plY3QuY29tbWVudEJ5Q29tbWVudCcoaWQsIGlkUHJvamVjdCwgY29tbWVudElkLCBjb21tZW50KSB7XG4gICAgICAgICAgICBpZiAoISBNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgUHJvamVjdC51cGRhdGUoXG4gICAgICAgICAgICAgICAgeydjb21tZW50cy5faWQnOiBjb21tZW50SWR9LCBcbiAgICAgICAgICAgICAgICB7JHB1c2g6IHtcbiAgICAgICAgICAgICAgICAgICAgJ2NvbW1lbnRzLiQuc291c0NvbW1lbnQnOiBcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgJ2NvbW1lbnRzJyA6IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ19pZCcgOiBpZCAsIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnZnJvbSc6IHRoaXMudXNlcklkLCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbW1lbnQnOiBjb21tZW50IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApO1xuICAgICAgICB9LFxuICAgICAgICAncHJvamVjdC5sYW5lcycobGFuZXMsIGlkUHJvamVjdCkge1xuICAgICAgICAgICAgaWYgKCEgTWV0ZW9yLnVzZXJJZCgpKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNoZWNrKGlkUHJvamVjdCwgU3RyaW5nKTtcbiAgICAgICAgICAgIFByb2plY3QudXBkYXRlKFxuICAgICAgICAgICAgICAgIHsgX2lkOiBpZFByb2plY3QgfSxcbiAgICAgICAgICAgICAgICB7JHNldCA6eydsYW5lcyc6IGxhbmVzfX1cbiAgICAgICAgICAgICk7XG4gICAgICAgIH0sXG4gICAgICAgICdwcm9qZWN0LmFkZENhdGUnKHByb2plY3RJZCxjYXRlSWQsIEN1cnJlbnRQYWdlLCBsYWJlbCwgc3R5bGUsIHRpdGxlLCBjYXJkcykge1xuICAgICAgICAgICAgaWYgKCEgTWV0ZW9yLnVzZXJJZCgpKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFByb2plY3QudXBkYXRlKFxuICAgICAgICAgICAgICAgIHsgJ19pZCc6IHByb2plY3RJZCB9LFxuICAgICAgICAgICAgICAgIHskcHVzaCA6e1xuICAgICAgICAgICAgICAgICAgICAnbGFuZXMubGFuZXMnOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAnaWQnOiBjYXRlSWQsIFxuICAgICAgICAgICAgICAgICAgICAgICAgJ2N1cnJlbnRQYWdlJzogQ3VycmVudFBhZ2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAnbGFiZWwnOiBsYWJlbCxcbiAgICAgICAgICAgICAgICAgICAgICAgICdzdHlsZSc6IHN0eWxlLFxuICAgICAgICAgICAgICAgICAgICAgICAgJ3RpdGxlJzogdGl0bGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAnY2FyZHMnOiBjYXJkcyxcbiAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApO1xuICAgICAgICB9LFxuICAgICAgICAncHJvamVjdC5yZW1vdmVDYXRlJyhpZENhdGUsIGlkUHJvamVjdCkge1xuICAgICAgICAgICAgaWYgKCEgTWV0ZW9yLnVzZXJJZCgpKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFByb2plY3QudXBkYXRlKFxuICAgICAgICAgICAgICAgIHsgJ19pZCc6IGlkUHJvamVjdCB9LFxuICAgICAgICAgICAgICAgIHsgJHB1bGw6IHsgJ2xhbmVzLmxhbmVzJzogeyBpZDogaWRDYXRlIH0gfSB9XG4gICAgICAgICAgICAgICk7XG4gICAgICAgIH0sXG4gICAgICAgICdwcm9qZWN0LmltYWdlUHJvZmlsZScoaWRQcm9qZWN0LCBpbWFnZSkge1xuICAgICAgICAgICAgaWYgKCEgTWV0ZW9yLnVzZXJJZCgpKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFByb2plY3QudXBkYXRlKFxuICAgICAgICAgICAgICAgIHsgJ19pZCc6IGlkUHJvamVjdCB9LFxuICAgICAgICAgICAgICAgIHsgJHNldDogeyAncHJvZmlsZSc6IGltYWdlIH0gfVxuICAgICAgICAgICAgICApO1xuICAgICAgICB9LFxuICAgICAgICAncHJvamVjdC5pbWFnZUJhY2tncm91bmQnKGlkUHJvamVjdCwgaW1hZ2UpIHtcbiAgICAgICAgICAgIGlmICghIE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBQcm9qZWN0LnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7ICdfaWQnOiBpZFByb2plY3QgfSxcbiAgICAgICAgICAgICAgICB7ICRzZXQ6IHsgJ2JhY2tncm91bmQnOiBpbWFnZSB9IH1cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgfSxcbiAgICAgICAgJ3Byb2plY3QuaW5zZXJ0TGluaycoX2lkLCBpZExpbmssIGxpbmssIG5hbWUsIG9ydGhlck5hbWUpIHtcbiAgICAgICAgICAgIGlmICghIE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBQcm9qZWN0LnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7ICdfaWQnOiBfaWQgfSxcbiAgICAgICAgICAgICAgICB7JHB1c2ggOnsnb3JnYW5pc2F0aW9uLmxpbmtVcmwnOiB7XG4gICAgICAgICAgICAgICAgICAgIF9pZCA6IGlkTGluayxcbiAgICAgICAgICAgICAgICAgICAgbGluayA6IGxpbmssXG4gICAgICAgICAgICAgICAgICAgIG5hbWUgOiBuYW1lLFxuICAgICAgICAgICAgICAgICAgICBvcnRoZXJOYW1lOiBvcnRoZXJOYW1lLFxuICAgICAgICAgICAgICAgIH0gfSB9XG4gICAgICAgICAgICAgICk7XG4gICAgICAgIH0sXG4gICAgICAgICdwcm9qZWN0LnJlbW92ZUxpbmsnKF9pZCwgaWQpIHtcbiAgICAgICAgICAgIGlmICghIE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBQcm9qZWN0LnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7ICdfaWQnOiBfaWQgfSxcbiAgICAgICAgICAgICAgICB7JHB1bGwgOnsnb3JnYW5pc2F0aW9uLmxpbmtVcmwnOiB7XG4gICAgICAgICAgICAgICAgICAgIF9pZCA6IGlkLFxuICAgICAgICAgICAgICAgIH0gfSB9XG4gICAgICAgICAgICAgICk7XG4gICAgICAgIH0sXG4gICAgICAgICdwcm9qZWN0Lmluc2VydERlYWRMaW5lJyhfaWQsIGlkRGVhZExpbmUsIGRhdGUsIHRpdGxlKSB7XG4gICAgICAgICAgICBpZiAoISBNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgUHJvamVjdC51cGRhdGUoXG4gICAgICAgICAgICAgICAgeyAnX2lkJzogX2lkIH0sXG4gICAgICAgICAgICAgICAgeyRwdXNoIDp7J29yZ2FuaXNhdGlvbi5kZWFkbGluZSc6IHtcbiAgICAgICAgICAgICAgICAgICAgX2lkIDogaWREZWFkTGluZSxcbiAgICAgICAgICAgICAgICAgICAgZGF0ZSA6IGRhdGUsXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlIDogdGl0bGUsXG4gICAgICAgICAgICAgICAgfSB9IH1cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgfSxcbiAgICAgICAgJ3Byb2plY3QucmVtb3ZlRGVhZExpbmUnKF9pZCwgaWQpIHtcbiAgICAgICAgICAgIGlmICghIE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBQcm9qZWN0LnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7ICdfaWQnOiBfaWQgfSxcbiAgICAgICAgICAgICAgICB7JHB1bGwgOnsnb3JnYW5pc2F0aW9uLmRlYWRsaW5lJzoge1xuICAgICAgICAgICAgICAgICAgICBfaWQgOiBpZCxcbiAgICAgICAgICAgICAgICB9IH0gfVxuICAgICAgICAgICAgICApO1xuICAgICAgICB9LFxuICAgICAgICAncHJvamVjdC5mb3JtYXRvckNvbW1lbnQnKF9pZCwgZm9ybWF0b3JDb21tZW50KSB7XG4gICAgICAgICAgICBpZiAoISBNZXRlb3IudXNlcklkKCkgJiYgTWV0ZW9yLnVzZXIoKS5wcm9maWxlLnJvbGUgPT09IFwiYWRtaW5cIikge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBQcm9qZWN0LnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7ICdfaWQnOiBfaWQgfSxcbiAgICAgICAgICAgICAgICB7JHB1c2ggOnsgJ2Zvcm1hdG9yJzogZm9ybWF0b3JDb21tZW50IH0gfVxuICAgICAgICAgICAgICApO1xuICAgICAgICB9LFxuICAgICAgICAncHJvamVjdC5mb3JtYXRvckNvbW1lbkRlbGV0ZXQnKF9pZCwgaWQpIHtcbiAgICAgICAgICAgIGlmICghIE1ldGVvci51c2VySWQoKSAmJiBNZXRlb3IudXNlcigpLnByb2ZpbGUucm9sZSA9PT0gXCJhZG1pblwiKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFByb2plY3QudXBkYXRlKFxuICAgICAgICAgICAgICAgIHsgJ19pZCc6IF9pZCB9LFxuICAgICAgICAgICAgICAgIHskcHVsbCA6eyAnZm9ybWF0b3InOiB7IFwiaWRcIiA6IGlkIH0gfSB9XG4gICAgICAgICAgICAgICk7XG4gICAgICAgIH0sXG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbiBcbmV4cG9ydCBjb25zdCBQcm9tbyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdwcm9tbycpO1xuIFxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICAgIE1ldGVvci5wdWJsaXNoKCdwcm9tbycsIGZ1bmN0aW9uIHRhc2tzUHVibGljYXRpb24oKSB7XG4gICAgICByZXR1cm4gUHJvbW8uZmluZCgpO1xuICAgIH0pO1xuXG4gICAgTWV0ZW9yLm1ldGhvZHMoe1xuICAgICAgICAncHJvbW8uaW5zZXJ0Jyh2aWxsZSkge1xuICAgICAgICAgICAgY2hlY2sodmlsbGUsIFN0cmluZyk7XG4gICAgICAgICAgICBpZiAoISBNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgUHJvbW8uaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICB2aWxsZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICAgICdwcm9tby5yZW1vdmVWaWxsZScodmlsbGVJZCkge1xuICAgICAgICAgICAgY2hlY2sodmlsbGVJZCwgU3RyaW5nKTtcbiAgICAgICAgICAgIFByb21vLnJlbW92ZSh7IF9pZCA6IHZpbGxlSWQgfSk7XG4gICAgICAgIH0sXG4gICAgICAgICdwcm9tby5yZW1vdmUnKHNlbGVjdElkKSB7XG4gICAgICAgICAgICBjaGVjayhzZWxlY3RJZCwgU3RyaW5nKTtcbiAgICAgICAgICAgIFByb21vLnJlbW92ZShzZWxlY3RJZCk7XG4gICAgICAgIH0sXG4gICAgICAgICdwcm9tby51cGRhdGUnKHRhc2tJZCkge1xuICAgICAgICAgICAgY2hlY2sodGFza0lkLCBTdHJpbmcpO1xuICAgICAgICAgICAgY2hlY2soc2V0Q2hlY2tlZCwgQm9vbGVhbik7XG4gICAgICAgICAgICBQcm9tby51cGRhdGUodGFza0lkLCB7ICRzZXQ6IHByb21vIH0pO1xuICAgICAgICB9LFxuICAgICAgICAncHJvbW8uaW5zZXJ0UHJvbW8nKHByb21vLCB2aWxsZUlkKSB7XG4gICAgICAgICAgICBjaGVjayhwcm9tbywgU3RyaW5nKTtcbiAgICAgICAgICAgIGNoZWNrKHZpbGxlSWQsIFN0cmluZyk7XG4gICAgICAgICAgICBQcm9tby51cGRhdGUoeyBfaWQgOiB2aWxsZUlkIH0sIFxuICAgICAgICAgICAgICAgIHsgJHB1c2g6IFxuICAgICAgICAgICAgICAgICAgICB7IFwicHJvbW9cIiA6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAkZWFjaDogWyBwcm9tbyBdIFxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9IFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICk7XG4gICAgICAgIH0sXG4gICAgICAgICdwcm9tby5yZW1vdmVQcm9tbycocHJvbW8sIHZpbGxlSWQpIHtcbiAgICAgICAgICAgIGNoZWNrKHByb21vLCBTdHJpbmcpO1xuICAgICAgICAgICAgY2hlY2sodmlsbGVJZCwgU3RyaW5nKTtcbiAgICAgICAgICAgIFByb21vLnVwZGF0ZSh7IF9pZCA6IHZpbGxlSWQgfSwgXG4gICAgICAgICAgICAgICAgeyAkcHVsbDogXG4gICAgICAgICAgICAgICAgICAgIHsgJ3Byb21vJzogcHJvbW8gfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICk7XG4gICAgICAgIH0sXG4gICAgfSk7XG59IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgTWV0ZW9yLnB1Ymxpc2goJ2FsbFVzZXJzJywgZnVuY3Rpb24ocm9sZSkge1xuICAgIGlmKHJvbGUgPT09ICdhZG1pbicpe1xuICAgICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kKHt9LCB7ZmllbGRzOntlbWFpbHM6MSwgcHJvZmlsZToxLCBhYnNlbmNlczoxLCBwcmVzZW5jZXM6MSwganVzdGlmeToxLCB1bmp1c3RpZnk6IDEsIGV2ZW50OjF9fSlcbiAgICB9ZWxzZXtcbiAgICAgIHJldHVybiBNZXRlb3IudXNlcnMuZmluZCh7X2lkIDogdGhpcy51c2VySWR9LCB7ZmllbGRzOntlbWFpbHM6MSwgcHJvZmlsZToxLCBub3RpZmljYXRpb25zIDogMSwgYWJzZW5jZXM6MSwgcHJlc2VuY2VzOjEsIGp1c3RpZnk6MSwgdW5qdXN0aWZ5OiAxLCBldmVudDoxfX0pXG4gICAgfVxuICB9KVxuICBNZXRlb3IucHVibGlzaCgnYWxsVXNlcnNJbmZvJywgZnVuY3Rpb24oaW5mbykge1xuICAgIGlmKGluZm8ucm9sZSA9PT0gJ2FkbWluJyl7XG4gICAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmQoe19pZCA6IGluZm8uaWR9LCB7ZmllbGRzOntlbWFpbHM6MSwgcHJvZmlsZToxLCBldmVudDoxfX0pXG4gICAgfWVsc2V7XG4gICAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmQoe19pZCA6IHRoaXMudXNlcklkfSwge2ZpZWxkczp7ZW1haWxzOjEsIHByb2ZpbGU6MSwgZXZlbnQ6MX19KVxuICAgIH1cbiAgfSlcbiAgTWV0ZW9yLnB1Ymxpc2goJ2FsbFVzZXJzSW5mb0Rhc2hib2FyZCcsIGZ1bmN0aW9uKHJvbGUpIHtcbiAgICBpZihyb2xlID09PSAnYWRtaW4nKXtcbiAgICAgIHJldHVybiBNZXRlb3IudXNlcnMuZmluZCh7fSwge2ZpZWxkczp7ZW1haWxzOjEsIHByb2ZpbGU6MX19KVxuICAgIH1lbHNle1xuICAgICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kKHtfaWQgOiB0aGlzLnVzZXJJZH0sIHtmaWVsZHM6e2VtYWlsczoxLCBwcm9maWxlOjF9fSlcbiAgICB9XG4gIH0pXG4gIE1ldGVvci5wdWJsaXNoKCdhbGxVc2Vyc0Fic2VuY2VzJywgZnVuY3Rpb24ocm9sZSkge1xuICAgIGlmKHJvbGUgPT09ICdhZG1pbicpe1xuICAgICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kKHt9KVxuICAgIH1lbHNle1xuICAgICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kKHtfaWQgOiB0aGlzLnVzZXJJZH0sIHtmaWVsZHM6e2VtYWlsczoxLCBwcm9maWxlOjF9fSlcbiAgICB9XG4gIH0pXG4gIE1ldGVvci5wdWJsaXNoKCd1c2VyTmFtZScsIGZ1bmN0aW9uKHJvbGUpIHtcbiAgICBpZihyb2xlID09PSAnYWRtaW4nKXtcbiAgICAgIHJldHVybiBNZXRlb3IudXNlcnMuZmluZCh7fSlcbiAgICB9ZWxzZXtcbiAgICAgIHJldHVybiBNZXRlb3IudXNlcnMuZmluZCh7X2lkIDogdGhpcy51c2VySWR9LCB7ZmllbGRzOntwcm9maWxlOjF9fSlcbiAgICB9XG4gIH0pXG4gIE1ldGVvci5wdWJsaXNoKCdvd25Vc2VyJywgZnVuY3Rpb24oKSB7XG4gICAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmQoeydfaWQnOiB0aGlzLnVzZXJJZH0pXG4gIH0pXG5cbiAgTWV0ZW9yLnB1Ymxpc2goJ2Nvbm5lY3RlZFVzZXInLCBmdW5jdGlvbigpIHtcbiAgICAgIHJldHVybiBNZXRlb3IudXNlcnMuZmluZCh7X2lkIDogdGhpcy51c2VySWR9LCB7ZmllbGRzOntlbWFpbHM6MSwgcHJvZmlsZToxLCBldmVudDoxLCBhYnNlbmNlczoxfX0pXG4gIH0pO1xuXG4gIE1ldGVvci5wdWJsaXNoKCd1c2VycycsIGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiBNZXRlb3IudXNlcnMuZmluZCh7fSwge2ZpZWxkczogeyBwcm9maWxlOiAxLCBub3RpZmljYXRpb25zOiAxfX0pXG4gIH0pO1xuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgJ3VzZXIuYWJzZW5jZXMnKGRhdGUsIGNhdXNlKSB7XG4gICAgICBpZiAoIU1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgICB9XG4gICAgICBjaGVjayhkYXRlLCBTdHJpbmcpO1xuICAgICAgY2hlY2soY2F1c2UsIFN0cmluZyk7XG4gICAgICBQcm9qZWN0LnVwZGF0ZShcbiAgICAgICAgeyBfaWQ6IHRoaXMudXNlcklkIH0sXG4gICAgICAgIHsgJHB1c2g6IHsgJ2Fic2VuY2VzJzogZGF0ZSB9fVxuICAgICAgKTtcbiAgICB9LFxuICAgICd1c2VyLnByZXNlbmNlcycodXNlcklkLCBwcmVzZW5jZSkge1xuICAgICAgaWYgKCFNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgICAgfVxuICAgICAgY2hlY2sodXNlcklkLCBTdHJpbmcpO1xuICAgICAgY29uc3QgdXNlciA9IE1ldGVvci51c2Vycy5maW5kKHtfaWQ6IHVzZXJJZH0pLmZldGNoKCk7XG4gICAgICBpZih1c2VyLmxlbmd0aCA+IDApe1xuICAgICAgICBsZXQgcHJlc2VuY2VzID0gdXNlclswXS5wcmVzZW5jZXM7XG4gICAgICAgIGxldCBleGlzdERhdGUgPSBmYWxzZTtcbiAgICAgICAgbGV0IGV4aXN0VGltZSA9IGZhbHNlO1xuICAgICAgICBmb3IobGV0IGkgaW4gcHJlc2VuY2VzKXtcbiAgICAgICAgICBpZihwcmVzZW5jZXNbaV0uZGF0ZSA9PSBwcmVzZW5jZS5kYXRlKXtcbiAgICAgICAgICAgIGV4aXN0RGF0ZSA9IHRydWU7XG4gICAgICAgICAgICBpZihwcmVzZW5jZXNbaV0udGltZS50b1N0cmluZygpICE9PSBwcmVzZW5jZS50aW1lLnRvU3RyaW5nKCkgfHwgcHJlc2VuY2VzW2ldLmNvbW1lbnQgIT09IHByZXNlbmNlLmNvbW1lbnQpeyAgXG4gICAgICAgICAgICAgIGV4aXN0VGltZSA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmKGV4aXN0RGF0ZSl7XG4gICAgICAgICAgaWYoZXhpc3RUaW1lKXtcbiAgICAgICAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoXG4gICAgICAgICAgICAgIHtfaWQ6IHVzZXJJZH0sXG4gICAgICAgICAgICAgIHskcHVsbDp7J3ByZXNlbmNlcyc6IHsgZGF0ZTogcHJlc2VuY2UuZGF0ZSB9IH0gfVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoXG4gICAgICAgICAgICAgIHtfaWQ6IHVzZXJJZH0sXG4gICAgICAgICAgICAgIHskcHVzaDp7J3ByZXNlbmNlcyc6IHByZXNlbmNlfX1cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9ZWxzZXtcbiAgICAgICAgICBNZXRlb3IudXNlcnMudXBkYXRlKFxuICAgICAgICAgICAge19pZDogdXNlcklkfSxcbiAgICAgICAgICAgIHskcHVzaDp7J3ByZXNlbmNlcyc6IHByZXNlbmNlfX1cbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICAndXNlci5ub3RpZicodXNlcklkLCBub3RpZiwgbGluaykge1xuICAgICAgaWYgKCFNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgICAgfVxuICAgICAgY2hlY2sodXNlcklkLCBTdHJpbmcpO1xuICAgICAgY2hlY2sobm90aWYsIFN0cmluZyk7XG4gICAgICBjaGVjayhsaW5rLCBTdHJpbmcpO1xuICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShcbiAgICAgICAgeyBfaWQ6IHVzZXJJZCB9LFxuICAgICAgICB7ICRwdXNoOiB7IFxuICAgICAgICAgICdwcm9maWxlLm5vdGlmaWNhdGlvbnMnOiB7XG4gICAgICAgICAgICAnbm90aWYnOiBub3RpZixcbiAgICAgICAgICAgICdsaW5rJzogbGluayxcbiAgICAgICAgICAgICdjcmVhdGVkQXQnOiBuZXcgRGF0ZSgpLFxuICAgICAgICAgIH0gXG4gICAgICAgIH19XG4gICAgICApO1xuICAgIH0sXG4gICAgJ3VzZXIubm90aWZNdWx0aXBsZScodXNlcklkQXJyYXksIG5vdGlmLCBsaW5rKSB7XG4gICAgICBpZiAoIU1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgICB9XG4gICAgICBjaGVjayh1c2VySWRBcnJheSwgQXJyYXkpO1xuICAgICAgY2hlY2sobm90aWYsIFN0cmluZyk7XG4gICAgICBjaGVjayhsaW5rLCBTdHJpbmcpO1xuICAgICAgZm9yKGxldCBpIGluIHVzZXJJZEFycmF5KXtcbiAgICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShcbiAgICAgICAgICB7IF9pZDogdXNlcklkQXJyYXlbaV0gfSxcbiAgICAgICAgICB7ICRwdXNoOiB7IFxuICAgICAgICAgICAgJ3Byb2ZpbGUubm90aWZpY2F0aW9ucyc6IHtcbiAgICAgICAgICAgICAgJ25vdGlmJzogbm90aWYsXG4gICAgICAgICAgICAgICdsaW5rJzogbGluayxcbiAgICAgICAgICAgICAgJ2NyZWF0ZWRBdCc6IG5ldyBEYXRlKCksXG4gICAgICAgICAgICB9IFxuICAgICAgICAgIH19XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfSxcbiAgICAnZGVsZXRlTm90aWZpY2F0aW9uJygpIHtcbiAgICAgIGlmICghTWV0ZW9yLnVzZXJJZCgpKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICAgIH1cbiAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoXG4gICAgICAgIHsgX2lkOiB0aGlzLnVzZXJJZCB9LFxuICAgICAgICB7ICRzZXQ6IHsncHJvZmlsZS5ub3RpZmljYXRpb25zJzogW10gfSB9XG4gICAgICApO1xuICAgIH0sXG4gICAgJ2V2ZW50LmRlbGV0ZScodXNlcklkLCBldmVudElkKSB7XG4gICAgICBpZiAoIU1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgICB9XG4gICAgICBjaGVjayh1c2VySWQsIFN0cmluZyk7XG4gICAgICBNZXRlb3IudXNlcnMudXBkYXRlKFxuICAgICAgICB7IF9pZDogdXNlcklkIH0sXG4gICAgICAgIHsgJHB1bGw6IHsnZXZlbnQnOiB7ICdfaWQnIDogZXZlbnRJZCB9IH0gfVxuICAgICAgKTtcbiAgICB9LFxuICAgICdhYnNlbmNlLmluc2VydCcoZGF0ZSwgY2F1c2UsIGp1c3RpZmljYXRpZiwgdHlwZSwgbGluaykge1xuICAgICAgaWYgKCFNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgICAgfVxuICAgICAgY29uc3QgdXNlciA9IE1ldGVvci51c2Vycy5maW5kKHtfaWQ6IHRoaXMudXNlcklkfSkuZmV0Y2goKTtcbiAgICAgIGlmKHVzZXIubGVuZ3RoID4gMCl7XG4gICAgICAgIGxldCBhYnNlbmNlcyA9IHVzZXJbMF0uYWJzZW5jZXM7XG4gICAgICAgIGxldCBleGlzdERhdGUgPSBmYWxzZTtcbiAgICAgICAgZm9yKGxldCBpIGluIGFic2VuY2VzKXtcbiAgICAgICAgICBpZihhYnNlbmNlc1tpXS5kYXRlID09PSBkYXRlKXtcbiAgICAgICAgICAgIGV4aXN0RGF0ZSA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmKCFleGlzdERhdGUpe1xuICAgICAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoXG4gICAgICAgICAgICB7X2lkIDogdGhpcy51c2VySWR9LFxuICAgICAgICAgICAgeyAkcHVzaCA6IHsgXG4gICAgICAgICAgICAgICAgYWJzZW5jZXMgOiB7IFxuICAgICAgICAgICAgICAgICAgICBkYXRlLCBcbiAgICAgICAgICAgICAgICAgICAgY2F1c2UsIFxuICAgICAgICAgICAgICAgICAgICBqdXN0aWZpY2F0aWYsIFxuICAgICAgICAgICAgICAgICAgICB0eXBlLFxuICAgICAgICAgICAgICAgICAgICBsaW5rLFxuICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5IDogXCJcIixcbiAgICAgICAgICAgICAgICB9IFxuICAgICAgICAgICAgfSBcbiAgICAgICAgICB9KVxuICAgICAgICB9ZWxzZXtcbiAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdBbGxyZWFkeSBhZGRlZCB0byB0aGlzIGRhdGUgOicgKyBkYXRlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgJ2Fic2VuY2VNdWx0aXBsZS5pbnNlcnQnKGRhdGUsIHRpbWUsIGNhdXNlLCBqdXN0aWZpY2F0aWYsIHR5cGUsIGxpbmspIHtcbiAgICAgIGlmICghTWV0ZW9yLnVzZXJJZCgpKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHVzZXIgPSBNZXRlb3IudXNlcnMuZmluZCh7X2lkOiB0aGlzLnVzZXJJZH0pLmZldGNoKCk7XG4gICAgICBpZih1c2VyLmxlbmd0aCA+IDApe1xuICAgICAgICBsZXQgYWJzZW5jZXMgPSB1c2VyWzBdLmFic2VuY2VzO1xuICAgICAgICBsZXQgZXhpc3REYXRlID0gZmFsc2U7XG4gICAgICAgIGZvcihsZXQgaSBpbiBhYnNlbmNlcyl7XG4gICAgICAgICAgaWYoYWJzZW5jZXNbaV0uZGF0ZSA9PT0gZGF0ZSl7XG4gICAgICAgICAgICBleGlzdERhdGUgPSB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZighZXhpc3REYXRlKXtcbiAgICAgICAgICBNZXRlb3IudXNlcnMudXBkYXRlKFxuICAgICAgICAgICAge19pZCA6IHRoaXMudXNlcklkfSxcbiAgICAgICAgICAgIHsgJHB1c2ggOiB7IFxuICAgICAgICAgICAgICBhYnNlbmNlcyA6IHtcbiAgICAgICAgICAgICAgICAgIGRhdGUsIFxuICAgICAgICAgICAgICAgICAgdGltZSxcbiAgICAgICAgICAgICAgICAgIGNhdXNlLCBcbiAgICAgICAgICAgICAgICAgIGp1c3RpZmljYXRpZiwgXG4gICAgICAgICAgICAgICAgICB0eXBlLFxuICAgICAgICAgICAgICAgICAgbGluayxcbiAgICAgICAgICAgICAgICAgIGp1c3RpZnkgOiBcIlwiLFxuICAgICAgICAgICAgICB9IFxuICAgICAgICAgICAgfSBcbiAgICAgICAgICB9XG4gICAgICAgIClcbiAgICAgIH1lbHNle1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdBbGxyZWFkeSBhZGRlZCB0byB0aGlzIGRhdGUgOicgKyBkYXRlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgfSwgXG4gICAgJ2Fic2VuY2UuanVzdGlmeScoX2lkLCBqdXN0aWZ5LCB0eXBlKSB7XG4gICAgICBpZiAoIU1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgICB9XG4gICAgICBpZihqdXN0aWZ5LmFic2VuY2VbMl0gIT09IFwiXCIpe1xuICAgICAgICBNZXRlb3IudXNlcnMudXBkYXRlKFxuICAgICAgICAgIHtfaWQgOiBfaWQsIFwiYWJzZW5jZXMuZGF0ZVwiIDoganVzdGlmeS5hYnNlbmNlWzJdLmRhdGV9LFxuICAgICAgICAgIHskc2V0IDogXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIFwiYWJzZW5jZXMuJC5qdXN0aWZ5XCIgOiB0cnVlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgaWYoanVzdGlmeS5hYnNlbmNlWzFdICE9PSBcIlwiKXtcbiAgICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShcbiAgICAgICAgICB7X2lkIDogX2lkLCBcInByZXNlbmNlcy5kYXRlXCIgOiBqdXN0aWZ5LmFic2VuY2VbMV0uZGF0ZX0sXG4gICAgICAgICAgeyRzZXQgOiBcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgXCJwcmVzZW5jZXMuJC5qdXN0aWZ5XCIgOiB0cnVlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShcbiAgICAgICAge19pZCA6IF9pZH0sXG4gICAgICAgIHskcHVzaCA6IFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIFwianVzdGlmeVwiIDogW2p1c3RpZnkuYWJzZW5jZVswXSwgdHlwZV1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIClcbiAgICB9LCBcbiAgICAnYWJzZW5jZS5uZXdqdXN0aWZ5bGluaycobGluaywgZGF0ZSkge1xuICAgICAgaWYgKCFNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgICAgfVxuICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShcbiAgICAgICAge19pZCA6IHRoaXMudXNlcklkLCBcImFic2VuY2VzLmRhdGVcIiA6IGRhdGV9LFxuICAgICAgICB7JHNldCA6IFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIFwiYWJzZW5jZXMuJC5saW5rXCIgOiBsaW5rXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICApO1xuICAgIH0sXG4gICAgJ2Fic2VuY2UudW5KdXN0aWZ5JyhfaWQsIGp1c3RpZnksIHR5cGUpIHtcbiAgICAgIGlmICghTWV0ZW9yLnVzZXJJZCgpKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICAgIH1cbiAgICAgIGlmKGp1c3RpZnkuYWJzZW5jZVsyXSAhPT0gXCJcIil7XG4gICAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoXG4gICAgICAgICAge19pZCA6IF9pZCwgXCJhYnNlbmNlcy5kYXRlXCIgOiBqdXN0aWZ5LmFic2VuY2VbMl0uZGF0ZX0sXG4gICAgICAgICAgeyRzZXQgOiBcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgXCJhYnNlbmNlcy4kLmp1c3RpZnlcIiA6IGZhbHNlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgaWYoanVzdGlmeS5hYnNlbmNlWzFdICE9PSBcIlwiKXtcbiAgICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShcbiAgICAgICAgICB7X2lkIDogX2lkLCBcInByZXNlbmNlcy5kYXRlXCIgOiBqdXN0aWZ5LmFic2VuY2VbMV0uZGF0ZX0sXG4gICAgICAgICAgeyRzZXQgOiBcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgXCJwcmVzZW5jZXMuJC5qdXN0aWZ5XCIgOiBmYWxzZVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoXG4gICAgICAgIHtfaWQgOiBfaWR9LFxuICAgICAgICB7JHB1c2ggOiBcbiAgICAgICAgICB7XG4gICAgICAgICAgICBcInVuanVzdGlmeVwiIDogW2p1c3RpZnkuYWJzZW5jZVswXSwgdHlwZV1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIClcbiAgICB9LCBcbiAgICAnYWJzZW5jZS5kZWxldGUnKF9pZCwganVzdGlmeSkge1xuICAgICAgaWYgKCFNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgICAgfVxuICAgICAgaWYoanVzdGlmeS5hYnNlbmNlWzJdICE9PSBcIlwiKXtcbiAgICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShcbiAgICAgICAgICB7X2lkIDogX2lkLCBcImFic2VuY2VzLmRhdGVcIiA6IGp1c3RpZnkuYWJzZW5jZVsyXS5kYXRlfSxcbiAgICAgICAgICB7JHNldCA6IFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBcImFic2VuY2VzLiQuanVzdGlmeVwiIDogXCJkZWxldGVcIlxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGlmKGp1c3RpZnkuYWJzZW5jZVsxXSAhPT0gXCJcIil7XG4gICAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoXG4gICAgICAgICAge19pZCA6IF9pZCwgXCJwcmVzZW5jZXMuZGF0ZVwiIDoganVzdGlmeS5hYnNlbmNlWzFdLmRhdGV9LFxuICAgICAgICAgIHskc2V0IDogXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIFwicHJlc2VuY2VzLiQuanVzdGlmeVwiIDogXCJkZWxldGVcIlxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9LCBcbiAgfSk7XG59XG4iLCJpbXBvcnQgJy4vVXNlckNvbGxlY3Rpb24uanMnO1xuaW1wb3J0ICcuL0FsbG93LmpzJztcbmltcG9ydCAnLi9Gb3JtQ29sbGVjdGlvbi5qcyc7XG5pbXBvcnQgJy4vUHJvamVjdENvbGxlY3Rpb25zLmpzJztcbmltcG9ydCAnLi9Db2xsZWd1ZVRlc3QuanMnO1xuaW1wb3J0ICcuL1Byb21vQ29sbGVjdGlvbic7XG5pbXBvcnQgJy4vRmVlZEJhY2tDb2xsZWN0aW9uJzsiLCJcbmltcG9ydCB7IEluamVjdCB9IGZyb20gXCJtZXRlb3IvbWV0ZW9yaGFja3M6aW5qZWN0LWluaXRpYWxcIjtcbmltcG9ydCAnLi4vLi4vYXBpL2FwaS5qcyc7XG5cbmlmKE1ldGVvci5pc1NlcnZlcil7XG4gICAgTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhcIlN0YXJ0aW5nIHNlcnZlci4uLlwiKTtcbiAgICAgICAgcHJvY2Vzcy5lbnYuTUFJTF9VUkw9J3NtdHBzOi8vbWFybGFpci5iZXJ0cmFuZCU0MGdtYWlsLmNvbTpmQXJhbmQwbGVAc210cC5nbWFpbC5jb206NDY1J1xuICAgICAgICBcbiAgICAgICAgQWNjb3VudHMuZW1haWxUZW1wbGF0ZXMuZnJvbT0nYmVydHJhbmRAYmVjb2RlLm9yZyc7XG4gICAgICAgIEFjY291bnRzLmVtYWlsVGVtcGxhdGVzLnNpdGVOYW1lPSdnbWFpbC5jb20nO1xuXG4gICAgICAgIC8vIEFjY291bnRzLmVtYWlsVGVtcGxhdGVzLnZlcmlmeUVtYWlsLnN1YmplY3QgPSAodXNlcikgPT4ge1xuICAgICAgICAvLyAgICAgcmV0dXJuICdDb25maXJtIHlvdXIgYWRyZXNzIG1haWwnO1xuICAgICAgICAvLyB9XG4gICAgICAgIFxuICAgICAgICAvLyBBY2NvdW50cy5lbWFpbFRlbXBsYXRlcy52ZXJpZnlFbWFpbC5zdWJqZWN0ID0gKHVzZXIsIHVybCkgPT4ge1xuICAgICAgICAvLyAgICAgcmV0dXJuICdDbGljayBvbiB0aGUgZm9sbG93aW5nIGxpbmsgdG8gdmVyaWZ5IHlvdXIgYWRyZXNzIE1haWwgOiAnICsgdXJsO1xuICAgICAgICAvLyB9XG5cbiAgICAgICAgLy8gQWNjb3VudHMuY29uZmlnKHtcbiAgICAgICAgLy8gICAgIHNlbmRWZXJpZmljYXRpb25FbWFpbDp0cnVlXG4gICAgICAgIC8vIH0pXG5cbiAgICAgICAgSW5qZWN0LnJhd01vZEh0bWwoXCJhZGRMYW5ndWFnZVwiLCBmdW5jdGlvbihodG1sKSB7XG4gICAgICAgICAgICByZXR1cm4gaHRtbC5yZXBsYWNlKC88aHRtbD4vLCAnPGh0bWwgbGFuZz1cImVuXCI+Jyk7XG4gICAgICAgIH0pO1xuICAgIH0pXG59IiwibW9kdWxlLmV4cG9ydHMgPSB7XG4gIHNlcnZlcnM6IHtcbiAgICBvbmU6IHtcbiAgICAgIC8vIFRPRE86IHNldCBob3N0IGFkZHJlc3MsIHVzZXJuYW1lLCBhbmQgYXV0aGVudGljYXRpb24gbWV0aG9kXG4gICAgICBob3N0OiAnNTQuMjM3LjIxMy4yMTQnLFxuICAgICAgdXNlcm5hbWU6ICd1YnVudHUnLFxuICAgICAgcGVtOiAnL1VzZXJzL2JlbGVnYW4vRGVza3RvcC9iZXJ0cmFuZC5wZW0nXG4gICAgICAvLyBwYXNzd29yZDogJ2ZBcmFuZDBsZSdcbiAgICAgIC8vIG9yIG5laXRoZXIgZm9yIGF1dGhlbnRpY2F0ZSBmcm9tIHNzaC1hZ2VudFxuICAgIH1cbiAgfSxcblxuICBhcHA6IHtcbiAgICAvLyBUT0RPOiBjaGFuZ2UgYXBwIG5hbWUgYW5kIHBhdGhcbiAgICBuYW1lOiAnQmVjb2RlUHJvZmlsZU1hbmFnZXInLFxuICAgIHBhdGg6ICcuLi8nLFxuXG4gICAgc2VydmVyczoge1xuICAgICAgb25lOiB7fSxcbiAgICB9LFxuXG4gICAgYnVpbGRPcHRpb25zOiB7XG4gICAgICBzZXJ2ZXJPbmx5OiB0cnVlLFxuICAgIH0sXG5cbiAgICBlbnY6IHtcbiAgICAgIC8vIFRPRE86IENoYW5nZSB0byB5b3VyIGFwcCdzIHVybFxuICAgICAgLy8gSWYgeW91IGFyZSB1c2luZyBzc2wsIGl0IG5lZWRzIHRvIHN0YXJ0IHdpdGggaHR0cHM6Ly9cbiAgICAgIFJPT1RfVVJMOiAnaHR0cHM6Ly9teS5iZWNvZGUub3JnJyxcbiAgICAgIE1PTkdPX1VSTDogJ21vbmdvZGI6Ly9tb25nb2RiOjI3MDE3L21ldGVvclJlYWN0JyxcbiAgICAgIE1PTkdPX09QTE9HX1VSTDogJ21vbmdvZGI6Ly9tb25nb2RiL2xvY2FsJyxcbiAgICB9LFxuXG4gICAgZG9ja2VyOiB7XG4gICAgICAvLyBjaGFuZ2UgdG8gJ2FiZXJuaXgvbWV0ZW9yZDpiYXNlJyBpZiB5b3VyIGFwcCBpcyB1c2luZyBNZXRlb3IgMS40IC0gMS41XG4gICAgICBpbWFnZTogJ2FiZXJuaXgvbWV0ZW9yZDpub2RlLTguNC4wLWJhc2UnLFxuICAgICAgYXJnczogW1xuICAgICAgICAnLS1saW5rPW1vbmdvZGI6bW9uZ29kYidcbiAgICAgIF1cbiAgICB9LFxuXG4gICAgLy8gU2hvdyBwcm9ncmVzcyBiYXIgd2hpbGUgdXBsb2FkaW5nIGJ1bmRsZSB0byBzZXJ2ZXJcbiAgICAvLyBZb3UgbWlnaHQgbmVlZCB0byBkaXNhYmxlIGl0IG9uIENJIHNlcnZlcnNcbiAgICBlbmFibGVVcGxvYWRQcm9ncmVzc0JhcjogdHJ1ZVxuICB9LFxuXG4gIC8vIG1vbmdvOiB7XG4gIC8vICAgdmVyc2lvbjogJzMuNC4xJyxcbiAgLy8gICBzZXJ2ZXJzOiB7XG4gIC8vICAgICBvbmU6IHt9XG4gIC8vICAgfVxuICAvLyB9LFxuICBcblxuICAvLyAoT3B0aW9uYWwpXG4gIC8vIFVzZSB0aGUgcHJveHkgdG8gc2V0dXAgc3NsIG9yIHRvIHJvdXRlIHJlcXVlc3RzIHRvIHRoZSBjb3JyZWN0XG4gIC8vIGFwcCB3aGVuIHRoZXJlIGFyZSBzZXZlcmFsIGFwcHNcblxuICBwcm94eToge1xuICAgIGRvbWFpbnM6ICdteS5iZWNvZGUub3JnJyxcbiAgICBzc2w6IHtcbiAgICAgIC8vIEVuYWJsZSBsZXQncyBlbmNyeXB0IHRvIGNyZWF0ZSBmcmVlIGNlcnRpZmljYXRlc1xuICAgICAgbGV0c0VuY3J5cHRFbWFpbDogJ2JldHJhbmRAYmVjb2RlLm9yZycsXG4gICAgICBmb3JjZVNTTDogdHJ1ZVxuICAgIH1cbiAgfVxufTtcbiIsIm1vZHVsZS5leHBvcnRzID0ge1xuICBzZXJ2ZXJzOiB7XG4gICAgb25lOiB7XG4gICAgICAvLyBUT0RPOiBzZXQgaG9zdCBhZGRyZXNzLCB1c2VybmFtZSwgYW5kIGF1dGhlbnRpY2F0aW9uIG1ldGhvZFxuICAgICAgaG9zdDogJzE5Mi4xNjguMS4xMDAnLFxuICAgICAgdXNlcm5hbWU6ICd1YnVudHUnLFxuICAgICAgLy8gcGVtOiAnL1VzZXJzL2FkbWluL0Rlc2t0b3AvYmVydHJhbmQucGVtJ1xuICAgICAgcGFzc3dvcmQ6ICdmQXJhbmQwbGUnXG4gICAgICAvLyBvciBuZWl0aGVyIGZvciBhdXRoZW50aWNhdGUgZnJvbSBzc2gtYWdlbnRcbiAgICB9XG4gIH0sXG5cbiAgYXBwOiB7XG4gICAgLy8gVE9ETzogY2hhbmdlIGFwcCBuYW1lIGFuZCBwYXRoXG4gICAgbmFtZTogJ0JlY29kZVByb2ZpbGVNYW5hZ2VyJyxcbiAgICBwYXRoOiAnLi4vJyxcblxuICAgIHNlcnZlcnM6IHtcbiAgICAgIG9uZToge30sXG4gICAgfSxcblxuICAgIGJ1aWxkT3B0aW9uczoge1xuICAgICAgc2VydmVyT25seTogdHJ1ZSxcbiAgICB9LFxuXG4gICAgZW52OiB7XG4gICAgICAvLyBUT0RPOiBDaGFuZ2UgdG8geW91ciBhcHAncyB1cmxcbiAgICAgIC8vIElmIHlvdSBhcmUgdXNpbmcgc3NsLCBpdCBuZWVkcyB0byBzdGFydCB3aXRoIGh0dHBzOi8vXG4gICAgICBST09UX1VSTDogJ2h0dHA6Ly8xOTIuMTY4LjEuMTAwOjMwMDAnLFxuICAgICAgTU9OR09fVVJMOiAnbW9uZ29kYjovL21vbmdvZGI6MjcwMTcvbXliZWNvZGUnLFxuICAgICAgTU9OR09fT1BMT0dfVVJMOiAnbW9uZ29kYjovL21vbmdvZGIvbG9jYWwnLFxuICAgIH0sXG5cbiAgICBkb2NrZXI6IHtcbiAgICAgIC8vIGNoYW5nZSB0byAnYWJlcm5peC9tZXRlb3JkOmJhc2UnIGlmIHlvdXIgYXBwIGlzIHVzaW5nIE1ldGVvciAxLjQgLSAxLjVcbiAgICAgIGltYWdlOiAnYWJlcm5peC9tZXRlb3JkOm5vZGUtOC40LjAtYmFzZScsXG4gICAgfSxcblxuICAgIC8vIFNob3cgcHJvZ3Jlc3MgYmFyIHdoaWxlIHVwbG9hZGluZyBidW5kbGUgdG8gc2VydmVyXG4gICAgLy8gWW91IG1pZ2h0IG5lZWQgdG8gZGlzYWJsZSBpdCBvbiBDSSBzZXJ2ZXJzXG4gICAgZW5hYmxlVXBsb2FkUHJvZ3Jlc3NCYXI6IHRydWVcbiAgfSxcblxuICBtb25nbzoge1xuICAgIHZlcnNpb246ICczLjQuMScsXG4gICAgc2VydmVyczoge1xuICAgICAgb25lOiB7fVxuICAgIH1cbiAgfSxcbiAgXG5cbiAgLy8gKE9wdGlvbmFsKVxuICAvLyBVc2UgdGhlIHByb3h5IHRvIHNldHVwIHNzbCBvciB0byByb3V0ZSByZXF1ZXN0cyB0byB0aGUgY29ycmVjdFxuICAvLyBhcHAgd2hlbiB0aGVyZSBhcmUgc2V2ZXJhbCBhcHBzXG5cbiAgLy8gcHJveHk6IHtcbiAgLy8gICBkb21haW5zOiAnbWFybGFpcmJlcnRyYW5kLnRrLHd3dy5tYXJsYWlyYmVydHJhbmQudGsnLFxuICAvLyAgIHNzbDoge1xuICAvLyAgICAgLy8gRW5hYmxlIGxldCdzIGVuY3J5cHQgdG8gY3JlYXRlIGZyZWUgY2VydGlmaWNhdGVzXG4gIC8vICAgICBsZXRzRW5jcnlwdEVtYWlsOiAnYmV0cmFuZEBiZWNvZGUub3JnJyxcbiAgLy8gICAgIGZvcmNlU1NMOiB0cnVlXG4gIC8vICAgfVxuICAvLyB9XG59O1xuIiwiXG5pbXBvcnQgJy4uL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvbWFpbi5qcyc7Il19
